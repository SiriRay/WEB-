//
//  ListDemoView.swift
//  Calculator App
//
//  Created by Zezhen Xu on 10/18/20.
//

import SwiftUI

struct ListDemoView: View {
    @ObservedObject var mockModel: MockModel
    var body: some View {
        NavigationView {
            List {
                ForEach (1..<5) { num in
                    NavigationLink(
                        destination: MockDestinationView(),
                        label: {
                            Text("\(num)")
                        })
                }
            }
            .environmentObject(mockModel)
            .navigationTitle("StackViewDemo")
        }
    }
}

struct MockDestinationView: View {
    @EnvironmentObject var mockModel: MockModel;
    
    var body: some View {
        Text("\(mockModel.mockData)")
    }
}

class MockModel: ObservableObject {
    var mockData: Int = 10;
}

struct ListDemoView_Previews: PreviewProvider {
    static var previews: some View {
        ListDemoView(mockModel: MockModel())
//        EmptyView()
    }
}
