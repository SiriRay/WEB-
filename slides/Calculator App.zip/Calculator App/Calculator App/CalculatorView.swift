//
//  CalculatorView.swift
//  Calculator App
//
//  Created by Zezhen Xu on 10/18/20.
//

import SwiftUI

struct CalculatorView: View {
    @ObservedObject var calculatorViewModel: CalculatorViewModel = CalculatorViewModel()
    
    var body: some View {
        VStack (spacing: 20){
            ZStack {
                Rectangle()
                    .foregroundColor(.blue)
                HStack {
                    Text(calculatorViewModel.lastSymbol)
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        
                    Spacer()
                    Text("\(calculatorViewModel.displayValue)")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                }
                .padding()
            }
            .frame(height: 100)
            Group {
                HStack (spacing: 20) {
                    NumericButtonView(digit: 7)
                    NumericButtonView(digit: 8)
                    NumericButtonView(digit: 9)
                }
                HStack (spacing: 20) {
                    NumericButtonView(digit: 4)
                    NumericButtonView(digit: 5)
                    NumericButtonView(digit: 6)
                }
                HStack (spacing: 20) {
                    NumericButtonView(digit: 1)
                    NumericButtonView(digit: 2)
                    NumericButtonView(digit: 3)
                }
                HStack (spacing: 20) {
                    OperatorButtonView(symbol: "+")
                    NumericButtonView(digit: 0)
                    OperatorButtonView(symbol: "=")
                }
            }
            .frame(height: 100)
        }
        .padding()
        .environmentObject(calculatorViewModel)
    }
}

struct CalculatorView_Previews: PreviewProvider {
    static var previews: some View {
        CalculatorView()
            .previewDevice("iPhone 11")
    }
}

struct NumericButtonView: View {
    @EnvironmentObject var calculatorViewModel: CalculatorViewModel
    
    var digit: Int
    var body: some View {
        Button(action: {calculatorViewModel.digitTouched(digit)}, label: {
            ZStack {
                Rectangle()
                    .foregroundColor(.gray)
                Text("\(digit)")
                    .font(.title)
                    .foregroundColor(.white)
                    .padding()
            }
        })
        
    }
}



struct OperatorButtonView: View {
    @EnvironmentObject var calculatorViewModel: CalculatorViewModel
    
    var symbol: String
    var body: some View {
        Button(action: {
            calculatorViewModel.performOperation(symbol)
        },
        label: {
            ZStack {
                Rectangle()
                    .foregroundColor(.gray)
                Text("\(symbol)")
                    .font(.title)
                    .foregroundColor(.white)
                    .padding()
            }
        })
    }
}
