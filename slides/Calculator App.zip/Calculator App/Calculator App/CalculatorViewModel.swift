//
//  CalculatorViewModel.swift
//  Calculator App
//
//  Created by Zezhen Xu on 10/18/20.
//

import Foundation

class CalculatorViewModel: ObservableObject {
    private var model = CalculatorModel()
    
    @Published var displayValue: Int = 0
    @Published var lastSymbol: String = ""
    
    func digitTouched(_ digit: Int) {
        displayValue = displayValue*10 + digit
    }
    
    func performOperation(_ symbol: String) {
        lastSymbol = symbol
        model.setOperand(operand: displayValue)
        model.performOperation(symbol: symbol)
        if symbol == "=" {
            displayValue = model.result
        }
        else {
            displayValue = 0
        }
    }
}
