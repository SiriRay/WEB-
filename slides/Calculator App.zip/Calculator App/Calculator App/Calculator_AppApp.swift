//
//  Calculator_AppApp.swift
//  Calculator App
//
//  Created by Zezhen Xu on 10/18/20.
//

import SwiftUI

@main
struct Calculator_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
