//
//  AnimationDemoView.swift
//  Calculator App
//
//  Created by Zezhen Xu on 10/18/20.
//

import SwiftUI

struct AnimationDemoView: View {
    // State is like a simple ViewModel here
    @State var hello: Bool = true
    var body: some View {
        VStack {
            if hello {
                Text("Hello World")
            }
            else
            {
                Text("Goodbye World")
            }
            Button("Change") {
                withAnimation{
                    hello = !hello
                }
            }
        }
        
    }
}

struct AnimationDemoView_Previews: PreviewProvider {
    static var previews: some View {
        AnimationDemoView()
    }
}
