//
//  ContentView.swift
//  Calculator App
//
//  Created by Zezhen Xu on 10/18/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        CalculatorView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
