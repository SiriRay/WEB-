//
//  CalculatorModel.swift
//  Calculator App
//
//  Created by Zezhen Xu on 10/18/20.
//

import Foundation

class CalculatorModel {
    //A dummy calculator model to support simple addition operation
    private var operations: Dictionary<String, Operation> = [
        "+": Operation.AdditionOperation({$0 + $1}),
        "=": Operation.Equal
    ]
    private enum Operation {
        case AdditionOperation((Int, Int) -> Int)
        case Equal
    }
    private struct PendingAdditionOperationInfo {
        var additionFunction: (Int, Int) -> Int
        var firstOperand: Int
    }

    private var accumulator = 0  //intemediate result
    private var pending: PendingAdditionOperationInfo?
    var result: Int { get { return accumulator } }

    func setOperand(operand: Int) {
        accumulator = operand
    }
    
    func performOperation(symbol: String) {
            if let operation = operations[symbol] {
                switch operation {
                    case .AdditionOperation(let function):
                        executePendingAdditionOperation()
                        pending = PendingAdditionOperationInfo(additionFunction: function, firstOperand: accumulator)
                    case .Equal:
                        executePendingAdditionOperation()
                }
            }
        }
        
    private func executePendingAdditionOperation() {
        if pending != nil {
            accumulator = pending!.additionFunction(pending!.firstOperand, accumulator)
            pending = nil
        }
    }

}
