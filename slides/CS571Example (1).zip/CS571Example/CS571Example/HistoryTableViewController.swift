//
//  HistoryTableViewController.swift
//  CS571Example
//
//  Created by CHENGLONG HAO on 9/26/17.
//  Copyright © 2017 cs571. All rights reserved.
//

import UIKit

class HistoryTableViewController: UITableViewController {
    
    var equations = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1 //return number of sections
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return equations.count //return number of rows
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "historyTableViewCell", for: indexPath)
        if let historyTableViewCell = cell as? HistoryTableViewCell {
            let equation = equations[indexPath.row]
            historyTableViewCell.equationLabel.text = equation
        }
        return cell
    }
    
    @IBAction func backAction(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    

}
