//
//  HistoryTableViewCell.swift
//  CS571Example
//
//  Created by CHENGLONG HAO on 9/26/17.
//  Copyright © 2017 cs571. All rights reserved.
//

import UIKit

class HistoryTableViewCell: UITableViewCell {

    @IBOutlet weak var equationLabel: UILabel!
    

}
