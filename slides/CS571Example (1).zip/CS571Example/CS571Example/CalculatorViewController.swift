//
//  CalculatorViewController.swft
//  CS571Example
//
//  Created by CHENGLONG HAO on 9/11/17.
//  Copyright © 2017 cs571. All rights reserved.
//

import UIKit

class CalculatorViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    private var userIsInTheMiddleOfTyping = false
    private var displayValue: Int {
        get { return Int(display.text!)! }
        set { display.text = String(newValue) }
    }
    private var model = CalculatorModel()

    @IBOutlet weak var display: UILabel!
    
    @IBAction func touchDigit(_ sender: UIButton) {
        let digit = sender.currentTitle!
        if userIsInTheMiddleOfTyping {
            let textCurrentInDisplay = display.text!
            display.text = textCurrentInDisplay + digit
        } else {
            display.text = digit
        }
        userIsInTheMiddleOfTyping = true
    }
    
    @IBAction func performOperation(_ sender: UIButton) {
        if userIsInTheMiddleOfTyping {
            model.setOperand(operand: displayValue)
            userIsInTheMiddleOfTyping = false
        }
        if let methemacitalSymbol = sender.currentTitle {
            model.performOperation(symbol: methemacitalSymbol)
        }
        displayValue = model.result
    }
    
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let navigationController = segue.destination as? UINavigationController {
            if let historyTableViewController = navigationController.topViewController as? HistoryTableViewController {
                historyTableViewController.equations = model.history
            }
        }
     }
    

}

