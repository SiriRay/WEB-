//
//  CalculatorModel.swift
//  CS571Example
//
//  Created by CHENGLONG HAO on 9/26/17.
//  Copyright © 2017 cs571. All rights reserved.
//

import Foundation

class CalculatorModel {
    //A dummy calculator model to support simple addition operation
    
    private var accumulator = 0
    private var operations: Dictionary<String, Operation> = [
        "+": Operation.AdditionOperation({$0 + $1}),
        "=": Operation.Equal
    ]
    private enum Operation {
        case AdditionOperation((Int, Int) -> Int)
        case Equal
    }

    var result: Int {
        get {
            return accumulator
        }
    }

    func setOperand(operand: Int) {
        accumulator = operand
    }
    
    func performOperation(symbol: String) {
        if let operation = operations[symbol] {
            switch operation {
                case .AdditionOperation(let function):
                    executePendingAdditionOperation()
                    pending = PendingAdditionOperationInfo(additionFunction: function, firstOperand: accumulator, symbol: symbol)
                case .Equal:
                    executePendingAdditionOperation()
                    addNewEquationToHistory();
            }
        }
    }
    
    private var pending: PendingAdditionOperationInfo?
    
    private func executePendingAdditionOperation() {
        if pending != nil {
            if currentEquation == nil {
                currentEquation = "\(pending!.firstOperand) \(pending!.symbol) \(accumulator)"
            } else {
                currentEquation = currentEquation! + "\(pending!.symbol) \(accumulator)"
            }
            accumulator = pending!.additionFunction(pending!.firstOperand, accumulator)
            pending = nil
        }
    }
    
    private struct PendingAdditionOperationInfo {
        var additionFunction: (Int, Int) -> Int
        var firstOperand: Int
        var symbol: String
    }
    
    private var equations = [String]()
    private var currentEquation: String? = nil
    
    var history: [String] {
        get {
            return equations
        }
    }
    
    private func addNewEquationToHistory() {
        if currentEquation != nil {
            currentEquation = currentEquation! + " = \(result)"
            equations.append(currentEquation!)
            currentEquation = nil
        }
    }
}
