//
//  StockPortfolioView.swift
//  StockSearch
//
//  Created by Karthik Kancharla on 4/30/24.
//

import SwiftUI

//struct StockPortfolioView: View {
//    var body: some View {
//        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
//    }
//}

//#Preview {
//    StockPortfolioView()
//}
//
//
import SwiftUI

//struct StockPortfolioView: View {
//    var stock: PortfolioStock
//
//    var body: some View {
//        Text("Portfolio").font(.title2).fontWeight(.bold).padding(.bottom)
//        VStack(alignment: .leading, spacing: 10) {
//            if stock.quantity > 0 {
//                Group {
//                    Text("Shares Owned: \(stock.quantity)")
//                    Text("Avg. Cost / Share: \(stock.avgCost, specifier: "%.2f")")
//                    Text("Total Cost: \(stock.totalCost, specifier: "%.2f")")
//                    Text("Change: \(stock.change, specifier: "%.2f")")
//                    Text("Market Value: \(stock.marketValue, specifier: "%.2f")")
//                    if let changePercentage = stock.changePercentage {
//                        Text("Change (%): \(changePercentage, specifier: "%.2f")%")
//                    }
//                }
//                .font(.subheadline)
//                .padding(.leading, 10)
//            } else {
//                Text("You have 0 shares of \(stock.symbol). Start trading!")
//                    .font(.headline)
//                    .padding(.leading, 10)
//            }
//
//            Spacer()
//
//            Button(action: {
//                print("Trade button tapped")
//            }) {
//                Text("Trade")
//                    .fontWeight(.bold)
//                    .foregroundColor(.white)
//                    .padding()
//                    .background(Color.green)
//                    .cornerRadius(20)
//            }
//            .frame(maxWidth: .infinity, alignment: .trailing)
//            .padding(.trailing, 10)
//        }
//
//    }
//}

//struct StockPortfolioView_Previews: PreviewProvider {
//    static var previews: some View {
//        // Create an instance with default initializer parameters
//        var stock = PortfolioStock(id: "1", symbol: "AAPL", quantity: 3, totalCost: 513.69)
//        // Manually update the current price for preview purposes
//        stock.updateMarketValues(currentPrice: 171.23)
//
//        return StockPortfolioView(stock: stock)
//    }
//}


import SwiftUI

struct StockPortfolioView: View {
    @EnvironmentObject var portfolioViewModel: PortfolioViewModel
    let symbol: String
    let companyName: String
    let currentPrice: Double
    
    private var stock: PortfolioStock? {
        portfolioViewModel.stocks.first { $0.symbol == symbol }
    }
    
    @State private var showTradeSheet = false
    
    
    var body: some View {
        Text("Portfolio").font(.title2).padding(.bottom,0)
        HStack() {
            VStack(alignment: .leading) {
                if let stock = stock, stock.quantity > 0 {
                    Group {
                        HStack {
                            Text("Shares Owned:")
                                .fontWeight(.bold)

                            Text("\(stock.quantity)")
                        }
                        .padding(.bottom,8)
                        
                        HStack {
                            Text("Avg. Cost / Share:")
                                .fontWeight(.bold)

                            Text("$\(stock.avgCost, specifier: "%.2f")")
                        }
                        .padding(.bottom,8)
                        
                        HStack {
                            Text("Total Cost:")
                                .fontWeight(.bold)

                            Text("$\(stock.totalCost, specifier: "%.2f")")
                        }
                        .padding(.bottom,8)
                        
                        HStack {
                            Text("Change:")
                                .fontWeight(.bold)

                            Text("$\(stock.change, specifier: "%.2f")")
                                .foregroundColor(stock.change == 0 ? .secondary : (stock.change > 0 ? .green : .red))
                        }
                        .padding(.bottom, 8)

                        HStack {
                            Text("Market Value:")
                                .fontWeight(.bold)

                            Text("$\(stock.marketValue, specifier: "%.2f")")
                                .foregroundColor(stock.change == 0 ? .secondary : (stock.change > 0 ? .green : .red))
                        }

                        
                    }
                    .font(.subheadline)
                } else {
                    Text("You have 0 shares of \(symbol). Start trading!")
                        .font(.subheadline)
                        .fontWeight(.regular)
                }
            }
            .padding(0)
            
            Spacer()
            
            Button(action: {
                print("Trade button tapped")
                showTradeSheet = true
            }) {
                Text("Trade")
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding()
                    .frame(width: 120.0, height: 50)
                    .background(Color.green)
                    .cornerRadius(25)
            }
            .sheet(isPresented: $showTradeSheet) {
                            TradeSheetView(isPresented: $showTradeSheet, portfolioViewModel: portfolioViewModel, symbol: symbol, currentPrice: currentPrice, companyName: companyName)
                        }

            .padding(.horizontal)
        }
        .padding(.top,0)
        
    }
}
