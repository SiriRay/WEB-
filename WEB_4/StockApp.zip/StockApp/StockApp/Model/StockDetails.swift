import Foundation

struct StockDetails: Decodable {
    let ticker: String
    let name: String
    let exchange: String
    let lastPrice: Double
    let change: Double
    let changePercent: Double
    let lastTimestamp: Int
    let marketStatus: String
    let logo: URL
}


