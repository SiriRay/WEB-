

import Foundation


struct StockSummary: Decodable {
    let highPrice: Double
    let lowPrice: Double
    let openPrice: Double
    let prevClose: Double
    let timestamp: Int
    let marketStatus: String
    let ipoStartDate: String
    let industry: String
    let webpage: String
    let companyPeers: [String]
}
