import Foundation

struct Stock: Identifiable, Decodable {
    var id: String
    let symbol: String
    let companyName: String
    let currentPrice: Double
    let priceChange: Double
    let percentageChange: Double

    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case symbol
        case companyName
        case currentPrice = "price"
        case priceChange = "change"
        case percentageChange = "changePercent"
    }
}
