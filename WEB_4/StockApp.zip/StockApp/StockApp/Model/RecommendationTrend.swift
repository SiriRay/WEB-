import Foundation

// Define a model to represent the recommendation trends
struct RecommendationTrend: Codable {
    var buy: Int
    var hold: Int
    var sell: Int
    var strongBuy: Int
    var strongSell: Int
    var period: String
    var symbol: String
}

// Define a model for the response that includes an array of RecommendationTrend
struct RecommendationTrendsResponse: Codable {
    var trends: [RecommendationTrend]
}
