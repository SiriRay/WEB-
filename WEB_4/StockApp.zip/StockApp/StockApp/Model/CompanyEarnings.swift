import Foundation

// Define a model to represent individual company earnings
struct CompanyEarnings: Codable {
    var actual: Double
    var estimate: Double
    var period: String
    var surprise: Double
    var surprisePercent: Double
    var symbol: String
}

// Define a model for the response that includes an array of CompanyEarnings
struct CompanyEarningsResponse: Codable {
    var earnings: [CompanyEarnings]
}
