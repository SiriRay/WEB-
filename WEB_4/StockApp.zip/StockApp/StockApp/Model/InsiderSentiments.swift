import Foundation

struct InsiderSentiment: Codable {
    let symbol: String
    let year: Int
    let month: Int
    let change: Int
    let mspr: Double
}


struct InsiderSentimentResponse: Codable {
    let data: [InsiderSentiment]
    let symbol: String
}


extension InsiderSentimentManager {
    // Function to inject mock data directly for previews
    func loadMockData() {
        isLoading = false
        totalMspr = 1234.56
        positiveMspr = 1000.12
        negativeMspr = -234.44
        totalChange = 12000
        positiveChange = 12000
        negativeChange = -8000
        errorMessage = nil
    }
}
