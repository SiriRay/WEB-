import Foundation

struct AutocompleteResponse: Codable {
    var count: Int
    var result: [Autocomplete]
}

struct Autocomplete: Codable {
    var description: String
    var displaySymbol: String
    var symbol: String
    var type: String
}
