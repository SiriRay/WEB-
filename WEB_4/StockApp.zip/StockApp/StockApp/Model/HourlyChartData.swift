import Foundation

struct HourlyChartData: Decodable {
    let stockPriceData: [[Double]]
    let volumeData: [[Double]]

    enum CodingKeys: String, CodingKey {
        case stockPriceData = "stockPriceData"
        case volumeData = "volumeData"
    }
}
