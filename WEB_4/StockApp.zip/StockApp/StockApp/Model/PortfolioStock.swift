import Foundation

struct PortfolioResponse: Codable {
    let cashBalance: Double
    let netWorth: Double
    let portfolio: [PortfolioStock]
}

struct PortfolioStock: Codable, Identifiable {
    var id: String { symbol }  // Using `symbol` as the unique ID
    let symbol: String
    let quantity: Int
    let currentPrice: Double
    let marketValue: Double
    let averageCost: Double
    let changeInPriceFromCost: Double
    let changeInPricePercentFromCost: Double

    enum CodingKeys: String, CodingKey {
        case symbol = "ticker"  // Maps `ticker` in JSON to `symbol` in Swift
        case quantity, currentPrice, marketValue, averageCost
        case changeInPriceFromCost, changeInPricePercentFromCost
    }

    // Calculated properties to display changes
    var priceChange: Double { return changeInPriceFromCost }
    var percentageChange: Double { return changeInPricePercentFromCost }
}
