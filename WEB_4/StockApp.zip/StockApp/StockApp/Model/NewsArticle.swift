import Foundation

struct NewsArticle: Decodable {
    let image: String
    let headline: String
    let url: String
    let datetime: Int
    let summary: String
    let source: String

    // You might want to add a computed property to convert the timestamp to a Date or a formatted String.
    var publishedDate: Date {
        return Date(timeIntervalSince1970: TimeInterval(datetime))
    }
}
