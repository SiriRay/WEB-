struct HistoricalData: Codable {
    var volume: Int
    var vwPrice: Double
    var open: Double
    var close: Double
    var high: Double
    var low: Double
    var timestamp: Int
    var transactions: Int

    enum CodingKeys: String, CodingKey {
        case volume = "v", vwPrice = "vw", open = "o", close = "c", high = "h", low = "l", timestamp = "t", transactions = "n"
    }
}

struct HistoricalDataResponse: Codable {
    var ticker: String
    var results: [HistoricalData]
}
