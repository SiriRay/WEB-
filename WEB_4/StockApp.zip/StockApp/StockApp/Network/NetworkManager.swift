import Foundation

struct NetworkManager {
    static let shared = NetworkManager()
    private let urlSession = URLSession.shared
    private let baseURL = "http://localhost:3000/api/"
    



    func fetchWatchlist(completion: @escaping (Result<[WatchlistStock], Error>) -> Void) {
        let url = URL(string: "\(baseURL)watchlist")!
        executeRequest(url: url, completion: completion)
    }

    
    func checkFavoriteStatus(symbol: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        let url = URL(string: "\(baseURL)watchlist/\(symbol)")!
        print("Checking favorite status for: \(url.absoluteString)")
        urlSession.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error checking favorite status: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }
            guard let data = data, let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                print("No valid HTTP response or data received")
                completion(.failure(NetworkError.networkError(nil)))
                return
            }
            
            do {
                let json = try JSONDecoder().decode([String: Bool].self, from: data)
                if let isInWatchlist = json["isInWatchlist"] {
                    print("Is in watchlist: \(isInWatchlist)")
                    completion(.success(isInWatchlist))
                } else {
                    print("JSON did not contain 'isInWatchlist'")
                    completion(.failure(NetworkError.decodingError))
                }
            } catch {
                print("Decoding error: \(error.localizedDescription)")
                completion(.failure(error))
            }
        }.resume()
    }

    // Extend the NetworkManager to handle detailed watchlist addition
    func addToWatchlist(stock: StockDetails, completion: @escaping (Result<Void, Error>) -> Void) {
        let url = URL(string: "\(baseURL)watchlist/add")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "symbol": stock.ticker,
            "companyName": stock.name ,
            "price": stock.lastPrice,
            "change": stock.change ,
            "changePercent": stock.changePercent
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        urlSession.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 201 else {
                completion(.failure(NetworkError.networkError(nil)))
                return
            }
            completion(.success(()))
        }.resume()
    }

    // Method to remove a stock from the watchlist
    func removeFromWatchlist(symbol: String, completion: @escaping (Result<Void, Error>) -> Void) {
        let url = URL(string: "\(baseURL)watchlist/remove/\(symbol)")!
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        
        urlSession.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                completion(.failure(NetworkError.networkError(nil)))
                return
            }
            completion(.success(()))
        }.resume()
    }


    func fetchStockDetails(symbol: String, completion: @escaping (Result<StockDetails, Error>) -> Void) {
        let url = URL(string: "\(baseURL)stock-details/\(symbol)")!
        executeRequest(url: url, completion: completion)
    }
    
    func fetchStockSummary(symbol: String, completion: @escaping (Result<StockSummary, Error>) -> Void) {
            let url = URL(string: "\(baseURL)stock-summary/\(symbol)")!
            executeRequest(url: url, completion: completion)
        }

    func fetchInsiderSentiment(for symbol: String, completion: @escaping (Result<InsiderSentimentResponse, Error>) -> Void) {
           let url = URL(string: "\(baseURL)insider-sentiment/\(symbol)")!
           executeRequest(url: url, completion: completion)
       }
    
    func fetchRecommendationTrends(for symbol: String, completion: @escaping (Result<[RecommendationTrend], Error>) -> Void) {
            let url = URL(string: "\(baseURL)recommendation-trends/\(symbol)")!
            executeRequest(url: url, completion: completion)
        }
    
    func fetchCompanyEarnings(for symbol: String, completion: @escaping (Result<[CompanyEarnings], Error>) -> Void) {
            let url = URL(string: "\(baseURL)company-earnings/\(symbol)")!
            executeRequest(url: url, completion: completion)
        }
    
    

    
    func fetchPortfolio(completion: @escaping (Result<PortfolioResponse, Error>) -> Void) {
        let url = URL(string: "\(baseURL)enhanced-portfolio")!
        executeRequest(url: url, completion: completion)
    }
    
    func fetchLatestNews(for symbol: String, completion: @escaping (Result<[NewsArticle], Error>) -> Void) {
            let url = URL(string: "\(baseURL)latest-news/\(symbol)")!
            executeRequest(url: url, completion: completion)
        }
    
    func fetchSummaryChartsData(for symbol: String, completion: @escaping (Result<HourlyChartData, Error>) -> Void) {
            let url = URL(string: "\(baseURL)company/summary-charts-data?symbol=\(symbol)")!
            executeRequest(url: url, completion: completion)
        }
        
    
    private func executeRequest<T: Decodable>(url: URL, completion: @escaping (Result<T, Error>) -> Void) {
        print("Fetching data from URL: \(url.absoluteString)")
        urlSession.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("Network error: \(error?.localizedDescription ?? "Unknown error")")
                completion(.failure(error ?? NetworkError.networkError(nil)))
                return
            }

            do {
                let result = try JSONDecoder().decode(T.self, from: data)
                completion(.success(result))
            } catch {
                print("Decoding error: \(error.localizedDescription)")
                completion(.failure(NetworkError.decodingError))
            }
        }.resume()
    }
    
    func fetchAutocompleteSuggestions(for query: String, completion: @escaping (Result<[Autocomplete], Error>) -> Void) {
        let endpoint = "autocomplete?q=\(query)"
        let url = URL(string: "\(baseURL)\(endpoint)")!
        print("Fetching autocomplete suggestions for: \(query)")
        
        urlSession.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching autocomplete suggestions: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }
            guard let data = data, let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                print("No valid HTTP response or data received for autocomplete")
                completion(.failure(NetworkError.networkError(nil)))
                return
            }

            do {
                let suggestionsResponse = try JSONDecoder().decode(AutocompleteResponse.self, from: data)
                completion(.success(suggestionsResponse.result))
            } catch {
                print("Decoding error for autocomplete suggestions: \(error.localizedDescription)")
                completion(.failure(NetworkError.decodingError))
            }
        }.resume()
    }



    enum NetworkError: Error {
        case invalidURL
        case networkError(Error?)
        case decodingError
    }
}
