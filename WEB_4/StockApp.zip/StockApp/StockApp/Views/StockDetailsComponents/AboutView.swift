import SwiftUI

struct AboutView: View {
    var stockSummary: StockSummary?
    
    var body: some View {
        VStack(alignment: .leading){
            Text("About")
                .font(.title2)
                .fontWeight(.medium)
                .multilineTextAlignment(.leading)

                .padding(.bottom, 12.0)
            
            HStack {
                VStack(alignment: .leading, spacing: 10.0) {
                    Text("IPO Start Date:")
                        .font(.footnote)
                        .fontWeight(.semibold)
                    Text("Industry:")
                        .font(.footnote)
                        .fontWeight(.semibold)
                    Text("Webpage:")
                        .font(.footnote)
                        .fontWeight(.semibold)
                    Text("Company Peers:")
                        .font(.footnote)
                        .fontWeight(.semibold)
                }
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                
                
                
                VStack(alignment: .leading, spacing: 10) {
                    if let stockSummary = stockSummary {
                        Text(stockSummary.ipoStartDate)
                            .font(.footnote)
                        Text(stockSummary.industry)
                            .font(.footnote)
                        Link(stockSummary.webpage, destination: URL(string: stockSummary.webpage)!)
                            .foregroundColor(.blue)
                            .font(.footnote)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 4.0) {
                                ForEach(stockSummary.companyPeers, id: \.self) { peer in
                                    NavigationLink(destination: stockDetailsView(for: peer)) {
                                        HStack(spacing: 0.0) {
                                            Text(peer)
                                                .font(.caption)
                                                .foregroundColor(.blue)
                                            if peer != stockSummary.companyPeers.last {
                                                Text(",")
                                                    .font(.caption)
                                                    .foregroundColor(.blue)
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }
                }
                Spacer()
                
                // This pushes the two VStacks to the edges of the HStack.
            }
        }
        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
    }
    
    @ViewBuilder
        private func stockDetailsView(for symbol: String) -> some View {
            let detailsViewModel = StockDetailsManager(symbol: symbol)
            let summaryViewModel = StockSummaryManager()
            let insiderSentimentViewModel = InsiderSentimentManager()
            let recommManager = RecommManager()
            let earningsManager = CompanyManager()  // Instantiate the CompanyEarningsManager
            let newsManager = NewsManager()
            let portfolioManager = PortfolioManager()// Instantiate the NewsManager
            
            StockDetailsview(
                stockDetailsManager: detailsViewModel,
                stockSummaryManager: summaryViewModel,
                insiderSentimentManager: insiderSentimentViewModel,
                recommManager: recommManager,
                earningsManager: earningsManager,  // Add earningsManager to the parameters
                newsManager: newsManager, portfolioManager: portfolioManager  // Pass the newsManager to the StockDetailsview
            )

            .onAppear {
                detailsViewModel.loadStockDetails(symbol: symbol)
                summaryViewModel.loadStockSummary(forTicker: symbol)
                insiderSentimentViewModel.loadInsiderSentiments(for: symbol)
                recommManager.loadRecommendationTrends(for: symbol)
                earningsManager.loadCompanyEarnings(for: symbol)  // Load the company earnings
                newsManager.fetchNews(for: symbol)  // Fetch the news for the stock
            }
        }
    }




