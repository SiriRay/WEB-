import SwiftUI

struct InfoView: View {
    var details: StockDetails
    
    var body: some View {
        VStack(alignment: .leading, spacing: 11.0) {
            Text(details.ticker)
                .font(.title)
                .fontWeight(.bold)
                .multilineTextAlignment(.leading)

            HStack {
                Text(details.name)
                    .font(.body)
                    .foregroundColor(Color(red: 0.545, green: 0.549, blue: 0.566))
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                AsyncImage(url: details.logo) { image in
                    image.resizable()
                } placeholder: {
                    ProgressView()
                        .padding(.trailing, 5.0)
                }
                .frame(width: 40, height: 40)
                .cornerRadius(10.0)
            }
            
            // Third row: Price in one column and change in another
            HStack(alignment: .center) {
                Text(String(format: "$%.2f", details.lastPrice))
                    .font(.title2)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.leading)
                
                    Image(systemName: details.change >= 0 ? "arrow.up.right" : "arrow.down.right")
                        .renderingMode(.original)
                        .resizable(resizingMode: .stretch)
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(details.change >= 0 ? .green : .red)
                        .frame(width: 30.0, height: 20.0)
                    Text(String(format: "$%.2f (%.2f%%)", details.change, details.changePercent))
                    .font(.title3)
                        .foregroundColor(details.change >= 0 ? .green : .red)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        
    }
}

// Preview provider with mock data
struct InfoView_Previews: PreviewProvider {
    static var previews: some View {
        InfoView(details: mockStockDetails())
            .previewLayout(.sizeThatFits)
            .padding()
    }
    
    
    static func mockStockDetails() -> StockDetails {
            return StockDetails(
                ticker: "AAPL",
                name: "Apple Inc.",
                exchange: "NASDAQ",
                lastPrice: 172.49,
                change: 3.42,
                changePercent: 2.01,
                lastTimestamp: 1625097602,
                marketStatus: "Open",
                logo: URL(string: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Apple_logo_black.svg/1000px-Apple_logo_black.svg.png")!
            )
        }
    }
