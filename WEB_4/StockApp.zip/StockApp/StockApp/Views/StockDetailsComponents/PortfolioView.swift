import SwiftUI

struct PortfolioView: View {
    @ObservedObject var portfolioManager: PortfolioManager
    let symbol: String
    let companyName: String
    let currentPrice: Double
    
    private var stock: PortfolioStock? {
        portfolioManager.portfolioStocks.first { $0.symbol == symbol }
    }
    
    @State private var showTradeSheet = false
    
    var body: some View {
        VStack {
            Text("Portfolio").font(.title2).padding(.bottom, 0)
            HStack {
                VStack(alignment: .leading) {
                    if let stock = stock, stock.quantity > 0 {
                        Group {
                            StockInfoView(stock: stock)
                        }
                    } else {
                        Text("You have 0 shares of \(symbol). Start trading!")
                            .font(.subheadline)
                            .fontWeight(.regular)
                    }
                }
                .padding(0)
                
                Spacer()
                
                Button(action: {
                    print("Trade button tapped")
                    showTradeSheet = true
                }) {
                    Text("Trade")
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 120.0, height: 50)
                        .background(Color.green)
                        .cornerRadius(25)
                }
//                .sheet(isPresented: $showTradeSheet) {
//                    TradeSheetView(isPresented: $showTradeSheet, portfolioManager: portfolioManager, symbol: symbol, currentPrice: currentPrice, companyName: companyName)
//                }
                .padding(.horizontal)
            }
            .padding(.top, 0)
        }
    }
}

struct StockInfoView: View {
    let stock: PortfolioStock
    
    var body: some View {
        VStack {
            HStack {
                Text("Shares Owned:")
                    .fontWeight(.bold)
                Text("\(stock.quantity)")
            }
            .padding(.bottom, 8)
            
            HStack {
                Text("Avg. Cost / Share:")
                    .fontWeight(.bold)
                Text("$\(stock.averageCost, specifier: "%.2f")")
            }
            .padding(.bottom, 8)
            
            HStack {
                Text("Total Cost:")
                    .fontWeight(.bold)
                Text("$\(stock.marketValue, specifier: "%.2f")")
            }
            .padding(.bottom, 8)
            
            HStack {
                Text("Change:")
                    .fontWeight(.bold)
                Text("$\(stock.priceChange, specifier: "%.2f")")
                    .foregroundColor(stock.priceChange == 0 ? .secondary : (stock.priceChange > 0 ? .green : .red))
            }
            .padding(.bottom, 8)
            
            HStack {
                Text("Market Value:")
                    .fontWeight(.bold)
                Text("$\(stock.marketValue, specifier: "%.2f")")
                    .foregroundColor(stock.priceChange == 0 ? .secondary : (stock.priceChange > 0 ? .green : .red))
            }
        }
        .font(.subheadline)
    }
}
