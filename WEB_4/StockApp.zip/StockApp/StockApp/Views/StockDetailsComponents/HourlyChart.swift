import SwiftUI
import WebKit

struct HourlyChart: View {
    @ObservedObject var hourManager: HourManager
    var ticker: String
    var changePercent: Double  // Add this to receive the change percentage

    var body: some View {
        VStack {
            if hourManager.isLoading {
                ProgressView("Loading...")
            } else if let errorMessage = hourManager.errorMessage {
                Text("Error: \(errorMessage)")
            } else {
                WebView(htmlContent: generateChartHTML())
                    .frame(maxWidth: .infinity, maxHeight: 400)
            }
        }
        .onAppear {
            hourManager.fetchChartData(for: ticker)
        }
    }

    private func generateChartHTML() -> String {
        guard let data = hourManager.hourlyChartData else { return "" }
        let priceData = data.stockPriceData.map { "[\($0[0]), \($0[1])]" }.joined(separator: ",")

        let chartOptions = """
            {
                chart: {
                  
                },
                title: {
                    text: '\(ticker) Hourly Price Variation',
                    style: {
                        color: '#767676',
                    },
                },
                navigator: {
                    enabled: false,
                },
                rangeSelector: {
                    enabled: false,
                },
                xAxis: {
                    type: 'datetime',
                    endOnTick: false,
                    startOnTick: false,
                    dateTimeLabelFormats: {
                        minute: '%H:%M',
                    },
                },
                yAxis: {
                    opposite: true,
                    labels: {
                        align: 'left',
                        x: -15,
                        y: 0,
                    },
                },
                plotOptions: {
                    spline: {
                        color: \(changePercent < 0 ? "'#FF0000'" : "'#00FF00'"),
                        tooltip: {
                            valueDecimals: 2,
                        },
                    },
                },
                series: [
                    {
                        type: 'spline',
                        data: [\(priceData)],
                        name: '\(ticker) Stock Price',
                        tooltip: {
                            valueDecimals: 2,
                        },
                        pointPlacement: 'on',
                    }
                ]
            }
        """

        let html = """
            <html>
            <head>
                <meta name="viewport" content="initial-scale=1.0">
                <script src="https://code.highcharts.com/stock/highstock.js"></script>
                <script src="https://code.highcharts.com/modules/exporting.js"></script>
                <style>
                    body { margin: 0; height: 100%; display: flex; justify-content: center; align-items: center; }
                    #container { height: 100%; width: 100%; }
                </style>
            </head>
            <body>
                <div id="container"></div>
                <script>
                    Highcharts.stockChart('container', \(chartOptions));
                </script>
            </body>
            </html>
        """

        return html
    }
}
