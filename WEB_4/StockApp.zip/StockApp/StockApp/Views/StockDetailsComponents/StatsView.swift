import SwiftUI

struct StatsView: View {
    var stockSummary: StockSummary?

    var body: some View {
        VStack(alignment: .leading) {
            Text("Stats")
                .font(.title2)
                .fontWeight(.medium)
                .multilineTextAlignment(.leading)
                .padding(.bottom, 12.0)

            HStack {
                VStack(alignment: .leading, spacing: 10) {
                    if let stockSummary = stockSummary {
                        HStack {
                            Text("High Price:")
                                .font(.footnote)
                                .fontWeight(.semibold)
                            
                            Text("$\(stockSummary.highPrice, specifier: "%.2f")")
                                .font(.footnote)
                        }
                        
                        HStack {
                            Text("Low Price:")
                                .font(.footnote)
                                .fontWeight(.semibold)
                           
                            Text("$\(stockSummary.lowPrice, specifier: "%.2f")")
                                .font(.footnote)
                        }
                    }
                }
                Spacer()

                VStack(alignment: .leading, spacing: 10) {
                    if let stockSummary = stockSummary {
                        HStack {
                            Text("Open Price:")
                                .font(.footnote)
                                .fontWeight(.semibold)
                            
                            Text("$\(stockSummary.openPrice, specifier: "%.2f")")
                                .font(.footnote)
                        }
                        
                        HStack {
                            Text("Prev. Close:")
                                .font(.footnote)
                                .fontWeight(.semibold)
                           
                            Text("$\(stockSummary.prevClose, specifier: "%.2f")")
                                .font(.footnote)
                        }
                    }
                }
                Spacer()
                Spacer()
            }
            
        }
        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        
    }
}


struct StatsView_Previews: PreviewProvider {
    static var previews: some View {
        StatsView(stockSummary: StockSummary(
            highPrice: 173.75,
            lowPrice: 168.27,
            openPrice: 171.71,
            prevClose: 172.69,
            timestamp: 1616956800,
            marketStatus: "Close",
            ipoStartDate: "1980-12-12",
            industry: "Technology",
            webpage: "https://www.apple.com",
            companyPeers: ["AAPL", "DELL", "SMCI", "HPQ", "1337.HK"]
        ))
        .previewDevice("iPhone 15 Pro Max")
        .previewLayout(.sizeThatFits)
        .padding()
    }
}
