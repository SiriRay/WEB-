import Foundation

// Sample JSON matching the structure you expect from the API
let jsonData = """
{
    "ticker": "AAPL",
    "queryCount": 501,
    "resultsCount": 501,
    "adjusted": true,
    "results": [
        {
            "v": 123050000,
            "vw": 156.0357,
            "o": 156.71,
            "c": 157.96,
            "h": 158.23,
            "l": 153.27,
            "t": 1651464000000,
            "n": 1154671
        }
    ]
}
""".data(using: .utf8)!

// Attempt to decode the sample JSON into your HistoricalDataResponse struct
do {
    let decodedData = try JSONDecoder().decode(HistoricalDataResponse.self, from: jsonData)
    print("Decoded successfully: \(decodedData)")
} catch {
    print("Failed to decode: \(error)")
}
