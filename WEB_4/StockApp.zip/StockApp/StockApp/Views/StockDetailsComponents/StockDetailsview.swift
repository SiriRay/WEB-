import SwiftUI

struct StockDetailsview: View {
    @ObservedObject var stockDetailsManager: StockDetailsManager
    @ObservedObject var stockSummaryManager: StockSummaryManager
    @ObservedObject var insiderSentimentManager: InsiderSentimentManager
    @ObservedObject var recommManager: RecommManager // Manager for recommendation trends
    @ObservedObject var earningsManager: CompanyManager // Manager for company earnings
    @ObservedObject var newsManager: NewsManager // Assuming NewsManager is passed into this view
    @ObservedObject var portfolioManager: PortfolioManager
    


    var body: some View {

            VStack {
                if let details = stockDetailsManager.stockDetails, let summary = stockSummaryManager.stockSummary {
                    ScrollView {
                            InfoView(details: details)
                            ChartsView(ticker: details.ticker)
                        PortfolioView(portfolioManager : portfolioManager, symbol: details.ticker, companyName: details.name, currentPrice: details.lastPrice)
                            StatsView(stockSummary: summary)
                            AboutView(stockSummary: summary)
                            InsiderSentimentView(sentimentManager: insiderSentimentManager)
                            RecommView(recommManager: recommManager)
                            EarningsView(earningsManager: earningsManager)
                            NewsArticleView(articles: newsManager.newsArticles)
                    
                    }
                } else if stockDetailsManager.isLoading || stockSummaryManager.isLoading || insiderSentimentManager.isLoading {
                    Text("Loading...")
                } else if let errorMessage = stockDetailsManager.errorMessage {
                    Text("Error: \(errorMessage)")
                } else if let summaryErrorMessage = stockSummaryManager.errorMessage {
                    Text("Error: \(summaryErrorMessage)")
                } else if let sentimentErrorMessage = insiderSentimentManager.errorMessage {
                    Text("Error: \(sentimentErrorMessage)")
                }
            }
            .onAppear {
                if stockDetailsManager.stockDetails != nil {
                    // Only fetch news if stock details are already loaded
                    newsManager.fetchNews(for: stockDetailsManager.stockDetails!.ticker)
                }
                stockDetailsManager.checkFavoriteStatus()
            }
            .navigationTitle(stockDetailsManager.stockDetails?.ticker ?? "Stock Details")
                        .navigationBarTitleDisplayMode(.inline) // Ensures the title is inline
                        .toolbar {
                            ToolbarItem(placement: .navigationBarTrailing) {
                                Button(action: {
                                    stockDetailsManager.toggleFavorite()
                                }) {
                                    Image(systemName: stockDetailsManager.isFavorited ? "plus.circle.fill" : "plus.circle")
                                        .foregroundColor(stockDetailsManager.isFavorited ? .blue : .gray)
                                }
                            }
                        }
                    
                }
            }
