import SwiftUI

struct InsiderSentimentView: View {
    @ObservedObject var sentimentManager: InsiderSentimentManager
    
    var body: some View {
        VStack {
            if sentimentManager.isLoading {
                ProgressView()
            } else if let errorMessage = sentimentManager.errorMessage {
                Text(errorMessage)
            } else if !sentimentManager.insidersentiments.isEmpty {
                let firstSentiment = sentimentManager.insidersentiments[0]
                // Header
                
                VStack(alignment: .leading){
                    Text("Insights")
                        .font(.title2)
                        .fontWeight(.medium)
                        .multilineTextAlignment(.leading)
                        .padding(.top)
                    
                    
                    
                    VStack(alignment: .leading, spacing: 10) {
                        
                        
                        HStack {
                            Text("Insider Sentiments")
                                .font(.title2)
                                .fontWeight(.medium)
                                .frame(width: 380, alignment: .center)
                                .padding(.bottom)
                        }
                        
                        HStack {
                            VStack {
                                Text(firstSentiment.symbol)
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack {
                                Text("MSPR")
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack {
                                Text("Change")
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                        }
                        
                        // Total row
                        HStack {
                            VStack {
                                Text("Total")
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack {
                                Text("\(sentimentManager.totalMspr, specifier: "%.2f")")
                                    .font(.footnote)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack {
                                Text("\(sentimentManager.totalChange)")
                                    .font(.footnote)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                        }
                        
                        // Positive row
                        HStack {
                            VStack {
                                Text("Positive")
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack {
                                Text("\(sentimentManager.positiveMspr, specifier: "%.2f")")
                                    .font(.footnote)
                                
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack {
                                Text("\(sentimentManager.positiveChange)")
                                    .frame(width: 80, alignment: .leading)
                                    .font(.footnote)
                                Divider()
                            }
                        }
                        
                        // Negative row
                        HStack(alignment: .top) {
                            VStack {
                                Text("Negative")
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack {
                                Text("\(sentimentManager.negativeMspr, specifier: "%.2f")")
                                    .font(.footnote)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            Spacer()
                            VStack {
                                Text("\(sentimentManager.negativeChange)")
                                    .font(.footnote)
                                    .frame(width: 80, alignment: .leading)
                                Divider()
                            }
                        }
                    }
                }
                .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            } else {
                Text("No sentiment data available")
            }
        }
    }
}
