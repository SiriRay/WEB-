import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    var htmlContent: String

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.loadHTMLString(htmlContent, baseURL: nil)
    }
}

struct RecommView: View {
    @ObservedObject var recommManager: RecommManager
    
    var body: some View {
        VStack {
            if recommManager.isLoading {
                ProgressView("Loading...")
            } else if let errorMessage = recommManager.errorMessage {
                Text(errorMessage)
            } else {
                WebView(htmlContent: generateChartHTML())
                
                    .frame(height: 360)
                    .frame(maxWidth: .infinity, alignment: .center)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
    }
    
    private func generateChartHTML() -> String {
        let chartOptions = """
        {
            chart: { type: 'column', backgroundColor: 'white' },
            navigation: {
                      buttonOptions: {
                          enabled: true,
                      }
                  },
            title: { text: 'Recommendation Trends' },
            xAxis: {
                type: 'datetime',
                
                dateTimeLabelFormats: { month: '%Y-%m' },
                categories: \(recommManager.recommendationTrends.map { "\($0.period.split(separator: "-").prefix(2).joined(separator: "-"))" })
            },
            yAxis: {
                allowDecimals: false,
                min: 0,
                title: { text: '#Analysis'},
                
                tickInterval: 20
            },
            tooltip: {
                
                headerFormat: '<span>{point.key}</span><br/>',
                pointFormat: '<span style="{series.color}">{series.name}</span>:{point.y}<br/>',
                footerFormat: 'Total: {point.total}',
                shared: true,
                useHTML: true
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    dataLabels: {
                        enabled: true,
                        
                    }
                }
            },
           legend: {
                       
                       
                       useHTML: true,
                       layout: 'horizontal',
                       
                   },
            series: [
                { name: 'Strong Buy', data: \(recommManager.recommendationTrends.map { $0.strongBuy }), type: 'column', color: '#195f32' },
                { name: 'Buy', data: \(recommManager.recommendationTrends.map { $0.buy }), type: 'column', color: '#23af50' },
                { name: 'Hold', data: \(recommManager.recommendationTrends.map { $0.hold }), type: 'column', color: '#af7d28' },
                { name: 'Sell', data: \(recommManager.recommendationTrends.map { $0.sell }), type: 'column', color: '#f05050' },
                { name: 'Strong Sell', data: \(recommManager.recommendationTrends.map { $0.strongSell }), type: 'column', color: '#732828' }
            ]
        }
        """
    
        
        let html = """
            <html>
            <head>
            <meta name="viewport" content="width=device-width, initial-scale=0.85">
            <script src="https://code.highcharts.com/highcharts.js"></script>
            <script src="https://code.highcharts.com/modules/exporting.js"></script>
            <style>
                body {
                    display: flex;
                    justify-content: center;
                    align-items: flex-start;
                }
                #container {
                                        width: 90%;
                                        height: 100%;
                }
            </style>
            </head>
            <body>
            <div id="container"></div>
            <script>
            Highcharts.chart('container', \(chartOptions));
            </script>
            </body>
            </html>
            """
        
        return html
    }
}
