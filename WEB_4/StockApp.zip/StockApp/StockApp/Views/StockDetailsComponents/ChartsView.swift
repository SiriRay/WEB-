import SwiftUI

struct ChartsView: View {
    var ticker: String
    @ObservedObject var stockDetailsManager: StockDetailsManager
    @ObservedObject var histManager: HistManager
    @ObservedObject var hourManager: HourManager

    init(ticker: String) {
        self.ticker = ticker
        _stockDetailsManager = ObservedObject(initialValue: StockDetailsManager(symbol: ticker))
        _histManager = ObservedObject(initialValue: HistManager(ticker: ticker))
        _hourManager = ObservedObject(initialValue: HourManager(ticker: ticker))
    }

    var body: some View {
        TabView {
            if let changePercent = stockDetailsManager.stockDetails?.changePercent {
                HourlyChart(hourManager: hourManager, ticker: ticker, changePercent: changePercent)
                    .tabItem {
                        Label("Hourly", systemImage: "chart.xyaxis.line")
                    }
            }

            HistoricalChart(histManager: histManager)
                .tabItem {
                    Label("Historical", systemImage: "clock")
                }
        }
        .frame(width: 380.0, height: 400.0)
        .padding()
        .onAppear {
            stockDetailsManager.loadStockDetails(symbol: ticker)
        }
    }
}
