import SwiftUI
import Kingfisher

struct NewsArticleView: View {
    let articles: [NewsArticle]
    @State private var selectedArticle: NewsArticle?
    @State private var showDetail = false

    var body: some View {
        ForEach(Array(articles.enumerated()), id: \.element.url) { index, article in
            VStack(alignment: .leading) {
                if index == 0 {
                    commonView(article: article)
                } else {
                    otherArticleView(article: article)
                }
            }
            .onTapGesture {
                self.selectedArticle = article
                self.showDetail = true
            }
            .padding(.horizontal, 25)
        }
        .sheet(isPresented: $showDetail) {
            if let article = selectedArticle {
                ArticleDetailSheet(article: article, showingDetail: $showDetail)
            }
        }
    }
    
    // Helper function for formatting publication date to time ago
    private func timeAgoSinceDate(_ date: Date, currentDate: Date) -> String {
          let interval = currentDate.timeIntervalSince(date)
          if interval < 3600 {
              return "\(Int(interval / 60)) min" // Minutes only for less than an hour
          } else if interval < 86400 {
              let hours = Int(interval / 3600)
              let minutes = Int((interval.truncatingRemainder(dividingBy: 3600)) / 60)
              return "\(hours) hr, \(minutes) min" // Hours and minutes for less than a day
          } else {
              return "\(Int(interval / 3600)) hr" // Hours only for more than a day (fallback, can adjust if needed)
          }
      }
  

    // View for the first article
    @ViewBuilder
    private func commonView(article: NewsArticle) -> some View {
        Text("News")
            .font(.title2)
            .fontWeight(.medium)
            .multilineTextAlignment(.leading)
            .padding(.bottom, 10)

        KFImage(URL(string: article.image))
            .resizable()
            .aspectRatio(contentMode: .fill)
            .cornerRadius(8)

        Spacer()

        HStack {
            Text(article.source)
                .fontWeight(.medium)
                .foregroundColor(.secondary)
                .font(.system(size: 12))

            Text(timeAgoSinceDate(article.publishedDate, currentDate: Date()))
                .foregroundColor(.secondary)
                .font(.system(size: 12))
        }

        Spacer()

        Text(article.headline)
            .fontWeight(.semibold)
            .foregroundColor(.primary)
            .font(.system(size: 15))

        Divider()
    }

    // View for other articles
    @ViewBuilder
    private func otherArticleView(article: NewsArticle) -> some View {
        HStack {
            VStack(alignment: .leading) {
                HStack {
                    Text(article.source)
                        .fontWeight(.medium)
                        .foregroundColor(.secondary)
                        .font(.system(size: 12))

                    Text(timeAgoSinceDate(article.publishedDate, currentDate: Date()))
                        .foregroundColor(.secondary)
                        .font(.system(size: 12))
                }

                Text(article.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                    .font(.system(size: 15))
            }
            Spacer()
            KFImage(URL(string: article.image))
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 85, height: 85)
                .clipped()
                .cornerRadius(8)
        }
        .padding(.vertical, 5)
        Divider()
    }
}

struct ArticleDetailSheet: View {
    let article: NewsArticle
    @Binding var showingDetail: Bool  // Use this binding to show/hide the sheet

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading) {
                    Text("Article Source: \(article.source)")
                    Text("Published Date: \(article.publishedDate, formatter: itemFormatter)")
                    Text("Title: \(article.headline)")
                    Text("Description: \(article.summary)")
                    Link("Read More", destination: URL(string: article.url)!)

                    HStack {
                        Button("Share on Twitter") {
                            openSocialMedia("twitter", title: article.headline, url: article.url)
                        }
                        Button("Share on Facebook") {
                            openSocialMedia("facebook", url: article.url)
                        }
                    }
                }
                .padding()
                .navigationBarItems(trailing: Button("Close") {
                    showingDetail = false  // Update the state to close the sheet
                })
            }
        }
    }

    private func openSocialMedia(_ platform: String, title: String? = nil, url: String) {
        let encodedTitle = title?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let encodedUrl = url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let urlString: String
        
        if platform == "twitter" {
            urlString = "https://twitter.com/intent/tweet?text=\(encodedTitle)&url=\(encodedUrl)"
        } else {
            urlString = "https://www.facebook.com/sharer/sharer.php?u=\(encodedUrl)"
        }
        
        if let url = URL(string: urlString) {
            UIApplication.shared.open(url)
        }
    }
}

let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .long
    formatter.timeStyle = .medium
    return formatter
}()
