import SwiftUI
import WebKit

struct EarningsView: View {
    @ObservedObject var earningsManager: CompanyManager
    
    var body: some View {
        VStack {
            if earningsManager.isLoading {
                ProgressView("Loading...")
            } else if let errorMessage = earningsManager.errorMessage {
                Text(errorMessage)
            } else {
                WebView(htmlContent: generateChartHTML())
                    .frame(height: 360)
                    .frame(maxWidth: .infinity, alignment: .center)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
    }
    
    private func generateChartHTML() -> String {
        let categories = earningsManager.companyEarnings.map { "\($0.period) <br />Surprise: \($0.surprise)" }
        let joinedCategories = categories.joined(separator: "\",\"")
        let chartOptions = """
        {
            chart: { type: 'spline', backgroundColor: 'white'},
            navigation: {
                    buttonOptions: {
                        enabled: true,
                        
                    }
                },
            title: { text: 'Historical EPS Surprises'},
            xAxis: {
                        labels: {
                            
                            rotation: -45,
                        },
            categories: ["\(joinedCategories)"]
            },
            yAxis: {
                title: { text: 'Quarterly EPS' },
                            tickInterval: 0.25
                    },
            plotOptions: {
        
                series: {
                    label: { connectorAllowed: false }
        
                }
            },
            series: [
                { name: 'Actual', data: \(earningsManager.companyEarnings.map { $0.actual }), type: 'spline' },
                { name: 'Estimate', data: \(earningsManager.companyEarnings.map { $0.estimate }), type: 'spline' }
            ]
        }
        """
            let html = """
            <html>
            <head>
            <meta name="viewport" content="width=device-width, initial-scale=0.85">
            <script src="https://code.highcharts.com/highcharts.js"></script>
            <script src="https://code.highcharts.com/modules/exporting.js"></script>
            <style>
                body {
                    display: flex;
                    justify-content: center;
                    align-items: flex-start;
                }
                #container {
                    width: 90%;
                    height: 100%;
            
                }
            </style>
            </head>
            <body>
            <div id="container"></div>
            <script>
            Highcharts.chart('container', \(chartOptions));
            </script>
            </body>
            </html>
            """
        
        return html
    }
}
