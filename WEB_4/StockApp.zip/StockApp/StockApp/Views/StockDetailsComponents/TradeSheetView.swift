//
//  TradeSheetView.swift
//  StockApp
//
//  Created by Siri Varshini Rayapati on 5/2/24.
//

import SwiftUI

struct TradeSheetView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    TradeSheetView()
}
