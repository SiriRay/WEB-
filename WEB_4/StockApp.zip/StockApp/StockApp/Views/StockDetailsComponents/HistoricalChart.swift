import SwiftUI
import WebKit

struct HistoricalChart: View {
    @ObservedObject var histManager: HistManager

    var body: some View {
        VStack {
            if histManager.isLoading {
                ProgressView("Loading...")
            } else if let errorMessage = histManager.errorMessage {
                Text("Error: \(errorMessage)")
            } else {
                WebView(htmlContent: generateChartHTML())
                    .frame(maxWidth: .infinity, maxHeight: 400)
            }
        }
        .onAppear {
            histManager.loadHistoricalData(for: histManager.ticker)
        }
    }
    
    private func generateChartHTML() -> String {
        let ohlcData = histManager.historicalData.map { "[\($0.timestamp), \($0.open), \($0.high), \($0.low), \($0.close)]" }.joined(separator: ",")
        let volumeData = histManager.historicalData.map { "[\($0.timestamp), \($0.volume)]" }.joined(separator: ",")

        let chartOptions = """
            {
                chart: {
                    type: 'stockChart'
                },
                rangeSelector: {
                    selected: 2
                },
                title: {
                    text: '\(histManager.ticker) Historical'
                },
                subtitle: {
                    text: 'With SMA and Volume by Price technical indicators'
                },
                series: [{
                    type: 'candlestick',
                    name: '\(histManager.ticker)',
                    id: '\(histManager.ticker)',
                    data: [\(ohlcData)]
                }, {
                    type: 'column',
                    name: 'Volume',
                    id: 'volume',
                    data: [\(volumeData)],
                    yAxis: 1
                },{
                    type: 'vbp',
                    linkedTo: '\(histManager.ticker)',
                    params: {
                        volumeSeriesID: 'volume'
                    },
                    dataLabels: {
                        enabled: false
                    },
                    zoneLines: {
                        enabled: false
                    }
                }, {
                    type: 'sma',
                    linkedTo: '\(histManager.ticker)',
                    zIndex: 1,
                    marker: {
                        enabled: false
                    }
                }],
                 yAxis: [
                        {
                          startOnTick: false,
                          endOnTick: false,
                          labels: {
                            align: 'right',
                            x: -3,
                          },
                          title: {
                            text: 'OHLC',
                          },
                          height: '60%',
                          lineWidth: 2,
                          resize: {
                            enabled: true,
                          },
                        },
                        {
                          labels: {
                            align: 'right',
                            x: -3,
                          },
                          title: {
                            text: 'Volume',
                          },
                          top: '65%',
                          height: '35%',
                          offset: 0,
                          lineWidth: 2,
                        },
                      ],
                      tooltip: {
                        split: true,
                      }
            }
        """

        let html = """
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=0.85">
                <script src="https://code.highcharts.com/stock/highstock.js"></script>
                <script src="https://code.highcharts.com/stock/modules/exporting.js"></script>
                <script src="https://code.highcharts.com/stock/indicators/indicators.js"></script>
                <script src="https://code.highcharts.com/stock/indicators/volume-by-price.js"></script>
                <script src="https://code.highcharts.com/modules/accessibility.js"></script>
                <style>
                    body { margin: 0; display: flex; justify-content: center; align-items: center; }
                    #container { height: 90%; width: 100% }
                </style>
            </head>
            <body>
                <div id="container"></div>
                <script>
                    Highcharts.stockChart('container', \(chartOptions));
                </script>
            </body>
            </html>
        """

        return html
    }
}





