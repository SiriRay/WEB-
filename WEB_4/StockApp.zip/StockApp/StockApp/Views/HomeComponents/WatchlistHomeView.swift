import SwiftUI

struct WatchlistHomeView: View {
    @ObservedObject var watchlistManager: WatchlistManager
    
    var body: some View {
        ForEach(watchlistManager.watchlistStocks) { stock in
            NavigationLink(destination: stockDetailsView(stock: stock)) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading) {
                        Text(stock.symbol)
                            .font(.headline)
                            .fontWeight(.bold)
                        Text(stock.companyName)
                            .font(.subheadline)
                            .foregroundColor(Color(hue: 0.667, saturation: 0.02, brightness: 0.577))
                    }
                    Spacer()
                    VStack(alignment: .trailing) {
                        Text(String(format: "$%.2f", stock.currentPrice))
                            .font(.subheadline)
                            .fontWeight(.bold)
                        HStack(spacing: 2) {
                            Image(systemName: stock.priceChange >= 0 ? "arrow.up.right" : "arrow.down.right")
                                .foregroundColor(stock.priceChange >= 0 ? .green : .red)
                                .padding(.trailing, 13.0)
                            Text("$\(stock.priceChange, specifier: "%.2f") (\(stock.percentageChange, specifier: "%.2f")%)")
                                .font(.subheadline)
                                .foregroundColor(stock.priceChange >= 0 ? .green : .red)
                        }
                    }
                }
            }
        }
        .onDelete(perform: watchlistManager.deleteWatchlistStock)
        .onMove(perform: watchlistManager.moveWatchlistStock)
        .onAppear {
                    watchlistManager.fetchWatchlist()  // Ensures the latest watchlist is shown
                }
    }
    
    
    
    @ViewBuilder
    private func stockDetailsView(stock: WatchlistStock) -> some View {
        let detailsViewModel = StockDetailsManager(symbol: stock.symbol)
        let summaryViewModel = StockSummaryManager()
        let insiderSentimentViewModel = InsiderSentimentManager()
        let recommManager = RecommManager()
        let earningsManager = CompanyManager()  // Instantiate the CompanyEarningsManager
        let newsManager = NewsManager()  
        let portfolioManager = PortfolioManager()// Instantiate the NewsManager
        
        StockDetailsview(
            stockDetailsManager: detailsViewModel,
            stockSummaryManager: summaryViewModel,
            insiderSentimentManager: insiderSentimentViewModel,
            recommManager: recommManager,
            earningsManager: earningsManager,  // Add earningsManager to the parameters
            newsManager: newsManager, portfolioManager: portfolioManager  // Pass the newsManager to the StockDetailsview
        )
        .onAppear {
            detailsViewModel.loadStockDetails(symbol: stock.symbol)  // Load stock details
            summaryViewModel.loadStockSummary(forTicker: stock.symbol)  // Load stock summary
            insiderSentimentViewModel.loadInsiderSentiments(for: stock.symbol)  // Load insider sentiments
            recommManager.loadRecommendationTrends(for: stock.symbol)  // Load recommendation trends
            earningsManager.loadCompanyEarnings(for: stock.symbol)  // Load company earnings
            newsManager.fetchNews(for: stock.symbol)  // Fetch the news for the stock
        }
    }
}
