import SwiftUI

struct PortfolioHomeView: View {
    @ObservedObject var portfolioManager: PortfolioManager
    
    var body: some View {
        ForEach(portfolioManager.portfolioStocks) { stock in
            NavigationLink(destination: stockDetailsView(stock: stock)) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading) {
                        Text(stock.symbol)
                            .font(.headline)
                            .fontWeight(.bold)
                        Text("\(stock.quantity) shares")
                            .font(.subheadline)
                            .foregroundColor(Color(hue: 0.667, saturation: 0.02, brightness: 0.577))
                    }
                    Spacer()
                    VStack(alignment: .trailing) {
                        Text(String(format: "$%.2f", stock.marketValue))
                            .font(.subheadline)
                            .fontWeight(.bold)
                        HStack(spacing: 2) {
                            if stock.priceChange == 0 {
                                Image(systemName: "minus")
                                    .foregroundColor(.gray)
                                    .padding(.trailing, 13.0)
                                Text("$\(stock.priceChange, specifier: "%.2f") (\(stock.percentageChange, specifier: "%.2f")%)")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            } else {
                                Image(systemName: stock.priceChange > 0 ? "arrow.up.right" : "arrow.down.right")
                                    .foregroundColor(stock.priceChange > 0 ? .green : .red)
                                    .padding(.trailing, 13.0)
                                Text("$\(stock.priceChange, specifier: "%.2f") (\(stock.percentageChange, specifier: "%.2f")%)")
                                    .font(.subheadline)
                                    .foregroundColor(stock.priceChange > 0 ? .green : .red)
                            }
                        }
                    }
                }
            }
            
        }.onMove(perform: portfolioManager.movePortfolioStock)
    }

    @ViewBuilder
    private func stockDetailsView(stock: PortfolioStock) -> some View {
        let detailsViewModel = StockDetailsManager(symbol: stock.symbol)
        let summaryViewModel = StockSummaryManager()
        let insiderSentimentViewModel = InsiderSentimentManager()
        let recommManager = RecommManager()
        let earningsManager = CompanyManager()  // Instantiate the CompanyEarningsManager
        let newsManager = NewsManager()
        let portfolioManager = PortfolioManager()// Instantiate the NewsManager
        
        StockDetailsview(
            stockDetailsManager: detailsViewModel,
            stockSummaryManager: summaryViewModel,
            insiderSentimentManager: insiderSentimentViewModel,
            recommManager: recommManager,
            earningsManager: earningsManager,  // Add earningsManager to the parameters
            newsManager: newsManager, portfolioManager: portfolioManager  // Pass the newsManager to the StockDetailsview
        )
        .onAppear {
            detailsViewModel.loadStockDetails(symbol: stock.symbol)  // Load stock details
            summaryViewModel.loadStockSummary(forTicker: stock.symbol)  // Load stock summary
            insiderSentimentViewModel.loadInsiderSentiments(for: stock.symbol)  // Load insider sentiments
            recommManager.loadRecommendationTrends(for: stock.symbol)  // Load recommendation trends
            earningsManager.loadCompanyEarnings(for: stock.symbol)  // Load company earnings
            newsManager.fetchNews(for: stock.symbol)  // Fetch the news for the stock
        }
    }
}
