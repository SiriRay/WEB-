import SwiftUI

struct HomeView: View {
    @State private var searchText = ""
    @StateObject var stockManager = StockManager()
    @StateObject var watchlistManager = WatchlistManager()
    @StateObject var portfolioManager = PortfolioManager()
    @StateObject private var autoManager = AutoManager()
    
    private let debouncer = Debouncer(delay: 0.5)
    
    
    var body: some View {
        NavigationView {
            List {
                
                Section {
                    DateView(date: stockManager.date)
                }
                
                Section(header: Text("Portfolio")) {
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Net Worth")
                                .font(.title3)
                            Text("$\(portfolioManager.netWorth, specifier: "%.2f")")
                                .font(.headline)
                                .fontWeight(.bold)
                        }
                        Spacer()
                        VStack(alignment: .leading) {
                            Text("Cash Balance")
                                .font(.title3)
                            Text("$\(portfolioManager.cashBalance, specifier: "%.2f")")
                                .font(.headline)
                                .fontWeight(.bold)
                        }
                    }
                    PortfolioHomeView(portfolioManager: portfolioManager)
                }
                
                Section(header: Text("FAVORITES")) {
                    WatchlistHomeView(watchlistManager: watchlistManager)
                        .onAppear {
                            watchlistManager.fetchWatchlist()
                        }
                }
                
                Section {
                            Link(destination: URL(string: "https://finnhub.io")!) {
                                Text("Powered by finnhub.io")
                                    .font(.caption)
                                    .foregroundColor(Color(red: 0.607, green: 0.592, blue: 0.592))
                                    .multilineTextAlignment(.center)
                                    .frame(maxWidth: .infinity, alignment: .center)
                            }
                        }
                
                if !autoManager.suggestions.isEmpty {
                    ForEach(autoManager.suggestions, id: \.symbol) { suggestion in
                        Text("\(suggestion.displaySymbol) - \(suggestion.description)")
                            .onTapGesture {
                                // Navigate to detail view with suggestion.symbol
                            }
                    }
                }
            }
            .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always)) {
                ForEach(autoManager.suggestions, id: \.symbol) { suggestion in
                    NavigationLink(destination: stockDetailsView(symbol: suggestion.symbol)) {
                        Text("\(suggestion.displaySymbol) - \(suggestion.description)").searchCompletion(suggestion.symbol)
                    }
                }}
            
            .onChange(of: searchText) { _, newValue in
                debouncer.run {
                    autoManager.fetchSuggestions(query: newValue)
                }
            }
        .navigationTitle("Stocks")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            EditButton()
        }
    }
}
}
@ViewBuilder
    private func stockDetailsView(symbol: String) -> some View {
        let detailsViewModel = StockDetailsManager(symbol: symbol)
        let summaryViewModel = StockSummaryManager()
        let insiderSentimentViewModel = InsiderSentimentManager()
        let recommManager = RecommManager()
        let earningsManager = CompanyManager()  // Instantiate the CompanyEarningsManager
        let newsManager = NewsManager()
        let portfolioManager = PortfolioManager()// Instantiate the NewsManager
        
        StockDetailsview(
            stockDetailsManager: detailsViewModel,
            stockSummaryManager: summaryViewModel,
            insiderSentimentManager: insiderSentimentViewModel,
            recommManager: recommManager,
            earningsManager: earningsManager,  // Add earningsManager to the parameters
            newsManager: newsManager, portfolioManager: portfolioManager  // Pass the newsManager to the StockDetailsview
        )
        .onAppear {
            detailsViewModel.loadStockDetails(symbol: symbol)
            summaryViewModel.loadStockSummary(forTicker: symbol)
            insiderSentimentViewModel.loadInsiderSentiments(for: symbol)
            recommManager.loadRecommendationTrends(for: symbol)
            earningsManager.loadCompanyEarnings(for: symbol)  // Load company earnings
            newsManager.fetchNews(for: symbol)
        }
    }


struct DateView: View {
    let date: Date

    var body: some View {
        Text(date, format: Date.FormatStyle().day().month(.wide).year())
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color(hue: 1.0, saturation: 0.03, brightness: 0.573, opacity: 0.922))
                    .multilineTextAlignment(.leading)
                    .padding(.all, 2.0)
                    .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// Preview
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
