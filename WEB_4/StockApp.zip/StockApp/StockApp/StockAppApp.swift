//
//  StockAppApp.swift
//  StockApp
//
//  Created by Siri Varshini Rayapati on 4/7/24.
//

import SwiftUI

@main
struct StockAppApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
