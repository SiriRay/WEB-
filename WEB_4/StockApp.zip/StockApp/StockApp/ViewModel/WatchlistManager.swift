import Foundation
import Combine

class WatchlistManager: ObservableObject {
    @Published var watchlistStocks: [WatchlistStock] = []
    @Published var errorMessage: String?  // Optional: Handle error messages in the UI

    init() {
        fetchWatchlist()
    }

    func fetchWatchlist() {
        NetworkManager.shared.fetchWatchlist { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let stocks):
                    self?.watchlistStocks = stocks
                case .failure(let error):
                    print("Error fetching watchlist: \(error)")
                    self?.errorMessage = "Failed to load watchlist"
                }
            }
        }
    }

    func deleteWatchlistStock(at offsets: IndexSet) {
        offsets.forEach { index in
            let symbol = watchlistStocks[index].symbol
            NetworkManager.shared.removeFromWatchlist(symbol: symbol) { [weak self] result in
                DispatchQueue.main.async {
                    switch result {
                    case .success:
                        self?.watchlistStocks.remove(at: index)
                    case .failure(let error):
                        print("Failed to delete stock: \(error)")
                        self?.errorMessage = "Failed to delete stock from watchlist"
                    }
                }
            }
        }
    }

    func moveWatchlistStock(from source: IndexSet, to destination: Int) {
        watchlistStocks.move(fromOffsets: source, toOffset: destination)
    }
}
