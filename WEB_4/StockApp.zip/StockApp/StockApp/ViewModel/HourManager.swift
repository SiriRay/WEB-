import Foundation
import Combine

class HourManager: ObservableObject {
    @Published var hourlyChartData: HourlyChartData?
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let networkManager = NetworkManager.shared
    private var ticker: String

    init(ticker: String) {
        self.ticker = ticker
    }

    func fetchChartData(for symbol: String) {
        isLoading = true
        networkManager.fetchSummaryChartsData(for: symbol) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let data):
                    self?.hourlyChartData = data
                case .failure(let error):
                    self?.errorMessage = "Failed to fetch data: \(error.localizedDescription)"
                }
            }
        }
    }
}
