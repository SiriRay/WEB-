import Foundation
import Combine

class AutoManager: ObservableObject {
    @Published var suggestions: [Autocomplete] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    private var cancellables: Set<AnyCancellable> = []

    // Fetch autocomplete suggestions from the server
    func fetchSuggestions(query: String) {
        guard !query.isEmpty else {
            suggestions = []
            return
        }

        isLoading = true
        NetworkManager.shared.fetchAutocompleteSuggestions(for: query) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let fetchedSuggestions):
                    self?.suggestions = fetchedSuggestions
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                    self?.suggestions = []  // Clear suggestions on error
                }
            }
        }
    }
}
