import Foundation

class CompanyManager: ObservableObject {
    @Published var companyEarnings: [CompanyEarnings] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    // Reference to the network manager
    private let networkManager = NetworkManager.shared

    // Fetch company earnings for a given symbol
    func loadCompanyEarnings(for symbol: String) {
        isLoading = true
        networkManager.fetchCompanyEarnings(for: symbol) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let earnings):
                    self?.companyEarnings = earnings
                case .failure(let error):
                    self?.errorMessage = "Failed to fetch data: \(error.localizedDescription)"
                }
            }
        }
    }
}
