import SwiftUI
import Combine

class PortfolioManager: ObservableObject {
    @Published var portfolioStocks: [PortfolioStock] = []
    @Published var cashBalance: Double = 0
    @Published var netWorth: Double = 0
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    init() {
        loadPortfolio()
    }

    func loadPortfolio() {
        print("Attempting to load portfolio...")
        isLoading = true
        NetworkManager.shared.fetchPortfolio { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let portfolioResponse): // Correctly handle PortfolioResponse
                    print("Received portfolio data: \(portfolioResponse)")
                    self?.portfolioStocks = portfolioResponse.portfolio
                    self?.cashBalance = portfolioResponse.cashBalance
                    self?.netWorth = portfolioResponse.netWorth
                case .failure(let error):
                    print("Error loading portfolio: \(error.localizedDescription)")
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
    func movePortfolioStock(from source: IndexSet, to destination: Int) {
        portfolioStocks.move(fromOffsets: source, toOffset: destination)
    }

}
