import Foundation
import Combine

class StockSummaryManager: ObservableObject {
    // Published properties that the view will observe
    @Published var stockSummary: StockSummary?
    @Published var isLoading = false
    @Published var errorMessage: String?

    private var cancellables = Set<AnyCancellable>()

    // Fetch stock summary by ticker symbol
    func loadStockSummary(forTicker ticker: String) {
        isLoading = true
        errorMessage = nil
        NetworkManager.shared.fetchStockSummary(symbol: ticker) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let summary):
                    self?.stockSummary = summary
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
}
