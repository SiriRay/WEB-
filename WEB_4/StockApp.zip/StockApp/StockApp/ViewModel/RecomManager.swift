import Foundation

class RecomManager: ObservableObject {
    @Published var recommendationTrends: [RecommendationTrend] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    
    private var networkManager = NetworkManager.shared
    
    func loadRecommendationTrends(for symbol: String) {
        isLoading = true
        networkManager.fetchRecommendationTrends(for: symbol) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let trends):
                    print("Received recommendation trends: \(trends)")
                    self?.recommendationTrends = trends
                case .failure(let error):
                    print("Error fetching recommendation trends: \(error.localizedDescription)")
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
}
