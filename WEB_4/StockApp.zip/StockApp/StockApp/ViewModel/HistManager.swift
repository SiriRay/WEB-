import Foundation

class HistManager: ObservableObject {
    @Published var historicalData: [HistoricalData] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var ticker: String = ""
    
    private let networkManager = NetworkManager.shared
    
    init(ticker: String) {
        self.ticker = ticker
        print("HistManager initialized with ticker: \(ticker)")
    }
    
    func loadHistoricalData(for symbol: String) {
        isLoading = true
        let urlString = "http://localhost:3000/api/historical-data/\(symbol)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }
        
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.isLoading = false
                
                if let error = error {
                    print("Network error: \(error.localizedDescription)")
                    self.errorMessage = "Network error: \(error.localizedDescription)"
                    return
                }
                
                guard let data = data else {
                    print("No data received")
                    self.errorMessage = "No data received"
                    return
                }
                
                do {
                    let decodedResponse = try JSONDecoder().decode(HistoricalDataResponse.self, from: data)
                    self.historicalData = decodedResponse.results
                    print("Successfully loaded historical data for \(symbol). Data count: \(decodedResponse.results.count)")
                } catch {
                    print("Decoding error: \(error)")
                    self.errorMessage = "Decoding error: \(error.localizedDescription)"
                }
            }
        }.resume()
    }
}
