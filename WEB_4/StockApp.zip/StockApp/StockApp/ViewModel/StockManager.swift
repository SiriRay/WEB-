import Foundation
import Combine

class StockManager: ObservableObject {
    @Published var searchText = ""
    @Published var date = Date()
    @Published var editingMode = false
    @Published var portfolioStocks: [Stock] = [
        Stock(id:"1",symbol: "AAPL", companyName: "aaple", currentPrice: 514.31,  priceChange: 0.22,percentageChange: 0.62),
        Stock(id:"2",symbol: "NVDA", companyName: "aaple", currentPrice: 2748.16,  priceChange: 0.22,percentageChange: -9.10)
    ]
    
    let netWorth: Double = 25009.72
    let cashBalance: Double = 21747.26
    
}
