import Foundation
import Combine

class InsiderSentimentManager: ObservableObject {
    @Published var insidersentiments: [InsiderSentiment] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    // Aggregate properties
    @Published var totalMspr: Double = 0
    @Published var positiveMspr: Double = 0
    @Published var negativeMspr: Double = 0
    @Published var totalChange: Int = 0
    @Published var positiveChange: Int = 0
    @Published var negativeChange: Int = 0

    private var networkManager = NetworkManager.shared

    func loadInsiderSentiments(for symbol: String) {
        isLoading = true
        networkManager.fetchInsiderSentiment(for: symbol) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let response):
                    self?.insidersentiments = response.data
                    self?.calculateAggregates(sentiments: response.data)
                case .failure(let error):
                    self?.errorMessage = "Failed to fetch data: \(error.localizedDescription)"
                }
            }
        }
    }

    private func calculateAggregates(sentiments: [InsiderSentiment]) {
        totalMspr = sentiments.reduce(0) { $0 + $1.mspr }
        positiveMspr = sentiments.filter { $0.mspr > 0 }.reduce(0) { $0 + $1.mspr }
        negativeMspr = sentiments.filter { $0.mspr < 0 }.reduce(0) { $0 + $1.mspr }
        
        totalChange = sentiments.reduce(0) { $0 + $1.change }
        positiveChange = sentiments.filter { $0.change > 0 }.reduce(0) { $0 + $1.change }
        negativeChange = sentiments.filter { $0.change < 0 }.reduce(0) { $0 + $1.change }
    }
}
