import Foundation

class NewsManager: ObservableObject {
    @Published var newsArticles: [NewsArticle] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    func fetchNews(for symbol: String) {
        isLoading = true
        errorMessage = nil
        
        NetworkManager.shared.fetchLatestNews(for: symbol) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let articles):
                    self?.newsArticles = articles
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
}
