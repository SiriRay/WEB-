import Foundation

class RecommManager: ObservableObject {
    @Published var recommendationTrends: [RecommendationTrend] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    // Reference to the network manager
    private let networkManager = NetworkManager.shared

    // Fetch recommendation trends for a given symbol
    func loadRecommendationTrends(for symbol: String) {
        isLoading = true
        networkManager.fetchRecommendationTrends(for: symbol) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let trends):
                    self?.recommendationTrends = trends
                case .failure(let error):
                    self?.errorMessage = "Failed to fetch data: \(error.localizedDescription)"
                }
            }
        }
    }
}
