import Foundation
import Combine

class StockDetailsManager: ObservableObject {
    @Published var stockDetails: StockDetails?
    @Published var isFavorited: Bool = false
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    @Published var transactionMessage: String?

    private var networkManager = NetworkManager.shared
    private let symbol: String

    init(symbol: String) {
        self.symbol = symbol
        loadStockDetails(symbol: symbol)
        checkFavoriteStatus()
    }

    func loadStockDetails(symbol: String) {
        isLoading = true
        errorMessage = nil
        networkManager.fetchStockDetails(symbol: symbol) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let details):
                    self?.stockDetails = details
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                    self?.stockDetails = nil
                }
            }
        }
    }

    func checkFavoriteStatus() {
        networkManager.checkFavoriteStatus(symbol: symbol) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let isFavorited):
                    self?.isFavorited = isFavorited
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                    self?.isFavorited = false
                }
            }
        }
    }

    func toggleFavorite() {
        guard let stock = stockDetails else {
            print("Stock details are not available.")
            return
        }

        if isFavorited {
            networkManager.removeFromWatchlist(symbol: stock.ticker) { [weak self] result in
                DispatchQueue.main.async {
                    switch result {
                    case .success:
                        self?.isFavorited = false
                        self?.transactionMessage = "\(stock.ticker) removed from watchlist."
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            self?.transactionMessage = nil
                        }
                        self?.checkFavoriteStatus()
                    case .failure(let error):
                        self?.errorMessage = "Failed to remove from watchlist: \(error.localizedDescription)"
                    }
                }
            }
        } else {
            networkManager.addToWatchlist(stock: stock) { [weak self] result in
                DispatchQueue.main.async {
                    switch result {
                    case .success:
                        self?.isFavorited = true
                        self?.transactionMessage = "\(stock.ticker) added to watchlist."
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                            self?.transactionMessage = nil
                        }
                        self?.checkFavoriteStatus()
                    case .failure(let error):
                        self?.errorMessage = "Failed to add to watchlist: \(error.localizedDescription)"
                    }
                }
            }
        }
    }
}
