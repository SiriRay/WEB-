import { Routes } from '@angular/router';

import { StockDetailsComponent } from './components/stock-details/stock-details.component';
import { WatchlistComponent } from './components/watchlist/watchlist.component';
import { PortfolioComponent } from './components/portfolio/portfolio.component';

export const routes: Routes = [
  { path: '', redirectTo: '/search/home', pathMatch: 'full' },
  { path: 'search/home', component: StockDetailsComponent },
  { path: 'search/:ticker', component: StockDetailsComponent },
  { path: 'watchlist', component: WatchlistComponent },
  { path: 'portfolio', component: PortfolioComponent },
  { path: '**', redirectTo: '/search/home' }, // Fallback route
];
