import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { BuySellModalComponent } from '../buy-sell-modal/buy-sell-modal.component';
import { StockService } from '../../stock.service';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { forkJoin, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-portfolio',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, NgbModule],
  templateUrl: './portfolio.component.html',
  styleUrl: './portfolio.component.css'
})
export class PortfolioComponent implements OnInit {
  portfolioStocks: any[] = [];
  currentBalance: number = 0;
  isLoading: boolean = true;
  isBuyTransaction: boolean = false;
  isSellTransaction: boolean = false;
  transactionMessage: string = '';
  isInitialized: boolean = false;

  constructor( private cdr: ChangeDetectorRef,private router: Router, private stockService: StockService, private modalService: NgbModal) {}

  ngOnInit(): void {
    this.fetchInitialData();
    this.fetchCurrentBalance();
    
  }

  private fetchInitialData(): void {
    forkJoin({
      portfolio: this.stockService.getPortfolioData(),
      balance: this.stockService.getCurrentBalance()
    })
    .pipe(
      catchError(error => {
        console.error('Error fetching initial data:', error);
        return of({ portfolio: [], balance: { balance: 0 } }); // Return default values in case of error
      }),
      finalize(() => {this.isLoading = false;this.isInitialized = true;} ) // Ensure isLoading is set to false once all operations are complete
    )
    .subscribe(({ portfolio, balance }) => {
      this.portfolioStocks = portfolio;
      this.currentBalance = balance.balance;
      this.calculateMarketValues();
      this.fetchTotalCosts();
      this.fetchCurrentBalance();
    });
  }


  getStyling(stock: any): any {
    // Ensure change is a number and round it to 2 decimal places
    const changeRounded = Number(stock.change).toFixed(2);
  
    // Convert back to number for comparison
    const change = parseFloat(changeRounded);
  
    if (change > 0) {
      return { color: 'green' };
    } else if (change < 0) {
      return { color: 'red' };
    } else {
      return { color: 'black' };
    }
  }
  
  navigateToStockDetails(ticker: string) {
    this.router.navigate(['/search', ticker]);
  }
  clearTransactionMessage(): void {
    this.transactionMessage = '';
    this.isBuyTransaction = false;
    this.isSellTransaction = false;
  }

  private fetchPortfolio(): void {
    this.stockService.getPortfolioData().subscribe({
      next: portfolio => {
      this.portfolioStocks = [...portfolio];
       this.calculateMarketValues();
       this.fetchTotalCosts();
      },
      error: err => {
        this.isLoading = false;
      }
    });
  }

   private fetchTotalCosts(): void {
    const costObservables = this.portfolioStocks.map(stock => this.stockService.getTotalCostForStock(stock._id).pipe(
      catchError(error => {
        return of(null); // Return null in case of error, to avoid breaking the entire stream
      })
    ));

    forkJoin(costObservables).subscribe(results => {
      results.forEach((result, index) => {
        if (result) {
          const stock = this.portfolioStocks[index];
          stock.totalCost = result.totalCost;
          stock.totalQuantity = result.totalQuantity;
          stock.averageCostPerShare = result.totalCost / result.totalQuantity;
          stock.change = stock.averageCostPerShare - stock.details.lastPrice;
        }
      });
      this.cdr.detectChanges(); // Trigger change detection to update the view
    });
  }
  calculateMarketValues(): void {
    this.portfolioStocks.forEach(stock => {
      if (stock.details && stock.quantity) {
        const marketValue = stock.details.lastPrice * stock.quantity;
        stock.marketValue = marketValue;
      }
    });
  }

  fetchCurrentBalance(): void {
    this.stockService.getCurrentBalance().subscribe((response: { balance: number; }) => {
      this.currentBalance = response.balance;
      this.isLoading = false;
    }, (error: any) => {
      this.isLoading = false;
    });
  }

  
  openDialog(stockId: string, action: string): void {
    const stock = this.portfolioStocks.find(s => s._id === stockId);

    if (!stock.details) {
      return;
    }
    
    const modalRef = this.modalService.open(BuySellModalComponent, { size: 'md' });
    modalRef.componentInstance.data = {
      balance: this.currentBalance,
      stockPrice: stock.details.lastPrice,
      action: action,
      ticker: stock._id,
      quantity: 1, // Default starting quantity
      ownedQuantity: stock.quantity
    };
   
    modalRef.componentInstance.closeModal.subscribe((result: { action: string; quantity: number; }) => {
      if (result) {
        // Perform action based on the result (buy or sell)
        if (result.action === 'Buy') {
          this.onBuy(stock._id, result.quantity);
        } else if (result.action === 'Sell') {
          this.onSell(stock._id, result.quantity);
        }
      }
      modalRef.close(); // Close the modal
    });
  }
  

  onBuy(ticker: string, quantity: number) {
    const stock = this.portfolioStocks.find(s => s._id === ticker);
    if (!stock.details) {
      return;
    }
  
    // Fetch the latest stock details including the current price
    this.stockService.getStockProfile(ticker).subscribe({
      next: (stockDetails) => {
        const currentPrice = stockDetails.lastPrice;
  
        if (quantity <= 0) {
          return;
        }
  
        this.stockService.buyStock(stockDetails.ticker, quantity, currentPrice).subscribe({
          next: (response) => {
            if (response && response.message && response.message.updatedBalance !== null) {
              this.currentBalance = response.message.updatedBalance;
              if (stock.details) {
                stock.details.quantity += quantity;
                this.calculateMarketValues(); // Recalculate market values after the transaction
                this.cdr.detectChanges(); // Trigger change detection
              }
              this.transactionMessage = `${stockDetails.ticker} bought successfully`;
              this.isBuyTransaction = true;
              this.isSellTransaction = false;
              this.fetchPortfolio();
            }
            setTimeout(() => {
              this.clearTransactionMessage();
              this.cdr.detectChanges(); // Trigger change detection
            }, 3000); // Clear the message after 3 seconds
          },
          error: (err) => {
          }
        });
      },
      error: (error) => {
        console.error(`Failed to fetch stock details for ${ticker}`, error);
      }
    });
  }
  
  onSell(ticker: string, quantity: number) {
    const stockIndex = this.portfolioStocks.findIndex(s => s._id === ticker);
    if (stockIndex === -1 || this.portfolioStocks[stockIndex].details.quantity < 1) {
      console.error('Stock details not available for selling.');
      return;
    }
  
    this.stockService.getStockProfile(ticker).subscribe({
      next: (stockDetails) => {
        const currentPrice = stockDetails.lastPrice;
        if (quantity <= 0) {
          console.error('Please enter a valid quantity to sell.');
          return;
        }
        this.stockService.sellStock(stockDetails.ticker, quantity, currentPrice).subscribe({
          next: (response) => {
            if (response && response.message && response.message.updatedBalance !== null) {
              this.currentBalance = response.message.updatedBalance;
              // Update the stock details immediately after sell operation
              if (quantity >= this.portfolioStocks[stockIndex].quantity) {
                // If selling all or more of the stock, remove it from the array
                this.portfolioStocks.splice(stockIndex, 1);
              } else {
                this.portfolioStocks[stockIndex].quantity -= quantity; // Update the quantity after selling
              }
              this.calculateMarketValues();
              if (this.portfolioStocks.length === 0 || stockIndex === -1) {
                this.cdr.detectChanges(); // Explicitly trigger change detection if the portfolio is empty
              }
              this.transactionMessage = `${stockDetails.ticker} sold successfully`;
              this.isSellTransaction = true;
              // Clear transaction message after a delay
              setTimeout(() => this.clearTransactionMessage(), 3000);
            }
          },
          error: (err) => console.error('Failed to execute sell operation.', err)
        });
      },
      error: (error) => console.error(`Failed to fetch stock details for ${ticker}`, error)
    });
  }
  

}