import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

interface NewsArticle {
  category: string;
  datetime: number;
  headline: string;
  id: number;
  image: string;
  related: string;
  source: string;
  summary: string;
  url: string;
}

@Component({
  selector: 'app-news-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './news-modal.component.html',
  styleUrl: './news-modal.component.css'
})
export class NewsModalComponent {

  @Input() article!: NewsArticle;

  constructor(public activeModal: NgbActiveModal) {}

  get twitterShareUrl(): string {
    return `https://twitter.com/intent/tweet?text=${encodeURIComponent(this.article.headline)}&url=${encodeURIComponent(this.article.url)}`;
  }
  getFormattedDate(timestamp: number): Date {
    return new Date(timestamp * 1000);
  }

  get facebookShareUrl(): string {
    return `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(this.article.url)}`;
  }

  openLink(url: string): void {
    window.open(url, '_blank');
  }
}
