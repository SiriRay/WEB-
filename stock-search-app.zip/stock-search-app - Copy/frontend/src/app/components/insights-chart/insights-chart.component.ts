import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

import * as Highcharts from 'highcharts';
import { HighchartsChartModule } from 'highcharts-angular';

interface recommendationTrends {
  buy: number;
  hold: number;
  period: string;
  sell: number;
  strongBuy: number;
  strongSell: number;
  symbol: string;
}

interface companyEarnings {
  actual: number;            // Actual earnings per share
  estimate: number;          // Estimated earnings per share
  period: string;            // The reporting period
  surprise: number;          // The surprise amount in earnings per share
  surprisePercent: number;   // The surprise percentage
  symbol: string;            // The ticker symbol of the company
}


@Component({
  selector: 'app-insights-chart',
  standalone: true,
  imports: [HighchartsChartModule, CommonModule],
  templateUrl: './insights-chart.component.html',
  styleUrl: './insights-chart.component.css'
})
export class InsightsChartComponent {
  Highcharts: typeof Highcharts = Highcharts;
  chartConstructor: string = 'chart';
  recommendationOptions!: any;
  earningsOptions!: any;
  @Input() recommendationTrends: recommendationTrends[] = [];
  @Input() companyEarnings: companyEarnings[] = [];

  ngOnInit(){
    this.earningsOptions = {
      title: {
        text: 'Historical EPS Surprises',
      },
      yAxis: {
        title: {
          text: 'Quarterly EPS'
        }
      },
      xAxis: {
        categories: this.companyEarnings.map(data => data.period + "<br />Surprise: " + data.surprise)
      },
      chart: {
        backgroundColor: '#f5f5f5'
      },
      plotOptions: {
        series: {
          label: {
            connectorAllowed: false
          },
        }
      },
      series: [
        {
        type: 'spline',
        name: 'Actual',
        data: this.companyEarnings.map(data => data.actual)
        },
        {
          type: 'spline',
          name: 'Estimate',
          data: this.companyEarnings.map(data => data.estimate)
        }
      ]
    },
    this.recommendationOptions = {
    chart: {
      type: 'column',
      backgroundColor: '#f5f5f5'
    },
    title: {
      text: 'Recommendation trends',
    },
    xAxis: {
      type: 'datetime',
      dateTimeLabelFormats: {
        year: '%Y',
        month: '%m',
      },
      categories: this.recommendationTrends.map(data => data.period)
    },
    yAxis: {
      allowDecimals: false,
      min: 0,
      title: {
        text: '#Analysis'
      }
    },
    tooltip: {
      format: '<b>{key}</b><br/>{series.name}: {y}<br />Total: {point.stackTotal}'
    },
    plotOptions: {
      column: {
        stacking: 'normal',
        dataLabels: {
          enabled: true,
        }
      },
      
    },
    series: [
      {
      name: 'Strong Buy',
      data: this.recommendationTrends.map(data =>  data.strongBuy),
      type: 'column',
      color: '#195f32'
      },
      {
        name: 'Buy',
        data: this.recommendationTrends.map(data => data.buy),
        type: 'column',
        color: '#23af50'
      },
      {
        name: 'Hold',
        data: this.recommendationTrends.map(data => data.hold),
        type: 'column',
        color: '#af7d28'
      },
      {
        name: 'Sell',
        data: this.recommendationTrends.map(data => data.sell),
        type: 'column',
        color: '#f05050'
      },
      {
        name: 'Strong Sell',
        data: this.recommendationTrends.map(data => data.strongSell),
        type: 'column',
        color: '732828'
      }
    ]
}}}
  