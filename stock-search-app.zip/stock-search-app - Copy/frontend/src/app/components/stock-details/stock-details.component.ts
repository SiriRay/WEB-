import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { StockService } from '../../stock.service';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, finalize, forkJoin, switchMap } from 'rxjs';
import { BuySellModalComponent } from '../buy-sell-modal/buy-sell-modal.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatTabsModule } from '@angular/material/tabs'; // Import MatTabsModule
import { SummaryChartComponent } from '../summary-chart/summary-chart.component';
import { ChartsTabComponent } from '../charts/charts.component';
import { InsightsChartComponent } from '../insights-chart/insights-chart.component';
import { NewsModalComponent } from '../news-modal/news-modal.component';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Location } from '@angular/common';


interface AutocompleteResult {
  description: string;
  displaySymbol: string;
  symbol: string;
  type: string;
}

interface StockDetails {
  ticker: string;
  name: string;
  exchange: string;
  lastPrice: number;
  change: number;
  changePercent: number;
  lastTimestamp: number;
  marketStatus: string;
  logo: string;userOwnsStock: boolean;
  quantity: number;  
  isInWatchlist: boolean; // Ensure this is part of your StockDetails interface
}

interface StockSummary {
  highPrice: number;
  lowPrice: number;
  openPrice: number;
  prevClose: number;
  timestamp: number;
  marketStatus: string;
  ipoStartDate: string;
  industry: string;
  webpage: string;
  companyPeers: string[];
}

interface NewsArticle {
  category: string;
  datetime: number;
  headline: string;
  id: number;
  image: string;
  related: string;
  source: string;
  summary: string;
  url: string;
}

@Component({
  selector: 'app-stock-details',
  standalone: true,
  imports: [NewsModalComponent ,ChartsTabComponent, InsightsChartComponent , CommonModule, ReactiveFormsModule, FormsModule, NgbModule, MatTabsModule, SummaryChartComponent],
  templateUrl: './stock-details.component.html',
  styleUrl: './stock-details.component.css'
})
export class StockDetailsComponent implements OnInit, OnDestroy{
  ticker: string | null = null;
  searchTerm: FormControl = new FormControl();
  autocompleteResults: AutocompleteResult[] = [];
  stockDetails: StockDetails | null = null;
  errorMessage: string = '';
  stockSummary: StockSummary | null = null;
  newsArticles: NewsArticle[] = [];
  currentTimestamp: number = Date.now();// Inside StockDetailsComponent class
  insiderSentimentData: any = null;  
  buyQuantity = new FormControl(1);
  sellQuantity = new FormControl(1);
  isBuyTransaction: boolean = false;isWatchlistRemoval: boolean = false;
  private cancelAutocomplete$ = new Subject<void>();
  stockDetailsShown: boolean = false;

  isSellTransaction: boolean = false;isLoading: boolean = false;

  currentBalance: number = 0;transactionMessage: string = '';
  data: { balance: number; stockPrice: number; action: string; quantity?: number } = {
    balance: 0,
    stockPrice: 0,
    action: '',
    quantity: 0
  };  
  private updateInterval: any;
  dayData: any;
  historicalData: any;
  recommendationTrends: any | undefined;
  companyEarnings: any;


  constructor(
    private cdr: ChangeDetectorRef,
    private stockService: StockService,
    private router: Router,
    private route: ActivatedRoute, private modalService: NgbModal,private location: Location 
    
  ) {}

  ngOnInit(): void {
    this.restoreState();
    this.searchTerm.valueChanges.subscribe({
      next: value=>{
        this.initializeAutocomplete();
      }
    })
    this.fetchCurrentBalance();
    
    this.route.params.subscribe(params => {
      const symbol = params['ticker'];
      if (symbol) {
        this.ticker = symbol;
        this.searchTerm.setValue(symbol);
        this.fetchStockData(symbol);
      }
    });
    this.setupTimestampUpdate();
  
    window.addEventListener('beforeunload', () => {
      sessionStorage.removeItem('stockPageState');
    });
    document.addEventListener('click', this.handleClickOutsideAutocomplete);
  }
  
  private setupTimestampUpdate(): void {
    this.updateInterval = setInterval(() => {
      this.currentTimestamp = Date.now();
      this.saveState(); // Ensure the latest timestamp is saved
    }, 15000);
  }
  


  ngOnDestroy(): void {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
    window.removeEventListener('beforeunload', this.clearSessionStorageOnUnload);
  }

  private clearSessionStorageOnUnload = () => {
    sessionStorage.removeItem('stockPageState');
    document.removeEventListener('click', this.handleClickOutsideAutocomplete);

  }


  private handleClickOutsideAutocomplete = (event: MouseEvent): void => {
    // Assume your autocomplete panel has a class 'autocomplete-panel'
    const clickedInside = event.composedPath().some(element => {
      return (element as HTMLElement).classList?.contains('autocomplete-panel');
    });
    
    if (!clickedInside) {
      this.autocompleteResults = []; // Clear autocomplete results
    }
  };




  private saveState(): void {
    const state = {
      searchTerm: this.searchTerm.value,
      autocompleteResults: this.autocompleteResults,
      stockDetails: this.stockDetails,
      stockSummary: this.stockSummary,
      newsArticles: this.newsArticles,
      dayData: this.dayData,
      historicalData: this.historicalData,
      recommendationTrends: this.recommendationTrends,
      companyEarnings: this.companyEarnings,
      insiderSentimentData: this.insiderSentimentData,
      currentTimestamp: this.currentTimestamp
    };
    sessionStorage.setItem('stockPageState', JSON.stringify(state));
  }

  private restoreState(): void {
    const stateString = sessionStorage.getItem('stockPageState');
    if (stateString) {
      const state = JSON.parse(stateString);
      this.searchTerm.setValue(state.searchTerm);
      this.autocompleteResults = state.autocompleteResults;
      this.stockDetails = state.stockDetails;
      this.stockSummary = state.stockSummary;
      this.newsArticles = state.newsArticles;
      this.dayData = state.dayData;
      this.historicalData = state.historicalData;
      this.recommendationTrends = state.recommendationTrends;
      this.companyEarnings = state.companyEarnings;
      this.insiderSentimentData = state.insiderSentimentData;
      this.currentTimestamp = state.currentTimestamp;
      if (this.stockDetails && this.stockDetails.ticker) {
        const path = this.router.createUrlTree(['/search', this.stockDetails.ticker]).toString();
        this.location.go(path);
      }
    }
  }
  
  updateMarketStatusAndTimestamp(): void {
    if (!this.ticker) {
      console.warn('No ticker symbol available for updating market status.');
      return;
    }
  
    this.stockService.getStockProfile(this.ticker).subscribe(profile => {
      if (this.stockDetails) {
        this.stockDetails.marketStatus = profile.marketStatus;
      }
      this.currentTimestamp = Date.now();
    }, err => {
      console.error('Failed to update market status:', err);
    });
  }
  

  onSearch(): void {
    const query = this.searchTerm.value;
    if (!query) {
      this.errorMessage = 'Please enter a valid ticker.';
      return;
    }
    this.cancelAutocomplete(); // Add this line
    this.router.navigate(['/search', query]);
    this.fetchStockData(query);
    this.autocompleteResults = []; // Clear results on selection
    this.stockDetailsShown = true;
  }
  
  onSelect(symbol: string): void {
    this.searchTerm.setValue(symbol);
    this.cancelAutocomplete(); // Add this line
    this.router.navigate(['/search', symbol]);
    this.fetchStockData(symbol);
    this.autocompleteResults = []; // Clear results on selection
    this.stockDetailsShown = true;
  }
  
  private cancelAutocomplete(): void {
    this.cancelAutocomplete$.next(); // Emit a signal to cancel autocomplete
  }
  
  clearSearch(): void {
    this.searchTerm.setValue('');
    this.stockDetails = null;
    this.errorMessage = '';
    this.autocompleteResults = [];
    this.currentTimestamp = Date.now();
    sessionStorage.removeItem('stockPageState');
    this.router.navigate(['/search', 'home']);
    this.cancelAutocomplete();
    this.stockDetailsShown = false;
    
    // Reset other component states as necessary to reflect a "fresh" search/home page
  }
  

  private fetchCurrentBalance(): void {
    this.stockService.getCurrentBalance().subscribe({
      next: response => {
        this.currentBalance = response.balance;
      },
      error: err => {
        console.error('Failed to fetch current balance:', err);
      }
    });
  }

  private initializeAutocomplete(): void {
    this.searchTerm.valueChanges.pipe(
      debounceTime(300), // Wait for a pause in typing
      distinctUntilChanged(), 
      takeUntil(this.cancelAutocomplete$), // Listen for a cancel signal
      // Only proceed if the value has changed
      switchMap(query => {
        if (!query) {
          this.isLoading = false; // Stop showing the loading indicator
          return []; // Return an empty array if the query is empty
        }
        this.isLoading = true; // Start showing the loading indicator
        return this.stockService.searchStocks(query)
        .pipe(
          finalize(() => this.isLoading = false) // Always stop the loading indicator, whether the fetch succeeded or failed
        );
      })
    ).subscribe(results => {
      this.autocompleteResults = results.result;
      this.isLoading = false; // Ensure loading indicator is hidden after results are fetched
    }, err => {
      this.errorMessage = 'Error fetching autocomplete suggestions.';
      this.isLoading = false; // Ensure loading indicator is hidden if an error occurs
    });
  }

  openNewsModal(article: NewsArticle): void {
    const modalRef = this.modalService.open(NewsModalComponent, { size: 'md' });
    modalRef.componentInstance.article = article;
  }


  openDialog(action: string, stock: any): void {
    if (!this.stockDetails) {
      console.error('Stock details are not available.');
      return;
    }
  
    const modalRef = this.modalService.open(BuySellModalComponent, {
      size: 'md'
    });
  
    modalRef.componentInstance.data = {
      balance: this.currentBalance,
      stockPrice: this.stockDetails.lastPrice,
      action: action,
      ticker: this.stockDetails.ticker,
      quantity: 0,
      ownedQuantity: stock.quantity
    };
  
    modalRef.componentInstance.closeModal.subscribe((result: { action: string; quantity: number; }) => {
      if (result) {
        // Perform action based on the result (buy or sell)
        if (result.action === 'Buy') {
          this.onBuy(result.quantity);
        } else if (result.action === 'Sell') {
          this.onSell(result.quantity);
        }
      }
      modalRef.close(); // Close the modal
    });
  }

  onBuy(quantity: number) {
    if (!this.stockDetails) {
      this.errorMessage = 'Stock details not available.';
      return;
    }
  
    const pricePerShare = this.stockDetails.lastPrice;
  
    if (quantity <= 0) {
      this.errorMessage = 'Please enter a valid quantity to buy.';
      return;
    }
  
    this.stockService.buyStock(this.stockDetails.ticker, quantity, pricePerShare).subscribe({
      next: response => {
        this.errorMessage = '';
        if (response && response.message && response.message.updatedBalance !== null) {
          // Update balance and stock ownership status
          this.currentBalance = response.message.updatedBalance;
          if (this.stockDetails) {
            this.stockDetails.userOwnsStock = true; // Assume ownership after purchase
            this.stockDetails.quantity = (this.stockDetails.quantity || 0) + quantity; // Update quantity
          }
// Update transaction message with optional chaining operator
          this.transactionMessage = `${this.stockDetails?.ticker} bought successfully`;
          this.isBuyTransaction = true;
          this.isSellTransaction = false;
        }
        setTimeout(() => {
          this.clearTransactionMessage();
          this.cdr.detectChanges(); // Trigger change detection
        }, 3000); // Clear the message after 3 seconds
       }, error: err => {
        this.errorMessage = err.error.error || 'Failed to execute buy operation.';
      }
    });
  }
  
  onSell(quantity: number) {
    if (!this.stockDetails || this.stockDetails.quantity < 1) {
      this.errorMessage = 'Insufficient stock quantity for selling.';
      return;
    }
  
    const pricePerShare = this.stockDetails.lastPrice;
  
    if (quantity <= 0) {
      this.errorMessage = 'Please enter a valid quantity to sell.';
      return;
    }
  
    this.stockService.sellStock(this.stockDetails.ticker, quantity, pricePerShare).subscribe({
      next: response => {
        this.errorMessage = '';
        if (response && response.message && response.message.updatedBalance !== null && response.message.updatedBalance !== undefined) {
          this.currentBalance = response.message.updatedBalance; // Update current balance
        }
        this.transactionMessage = `${this.stockDetails?.ticker} sold successfully`;
        this.isBuyTransaction = false;
        this.isSellTransaction = true;
    
        // Place setTimeout here, inside the next function
        setTimeout(() => {
          this.clearTransactionMessage();
          // Assuming this.cdr.detectChanges(); is needed for Angular Change Detection
          // Make sure cdr is defined as ChangeDetectorRef in your component
          this.cdr.detectChanges(); // Trigger change detection
        }, 3000); // Clear the message after 2 seconds, not 3 as the comment suggested
      },
      error: err => {
        this.errorMessage = err.error.error || 'Failed to execute sell operation.';
      }
    });
  }    

  clearTransactionMessage(): void {
    this.transactionMessage = '';
    this.isBuyTransaction = false;
    this.isSellTransaction = false;
  }

  
  toggleWatchlist(stock: StockDetails): void {
    if (!stock) {
      console.error('Stock details are not available.');
      return;
    }
  
    if (stock.isInWatchlist) {
      // If it's already in the watchlist, call the API to remove it.
      this.stockService.removeFromWatchlist(stock.ticker).subscribe({
        next: () => {
          stock.isInWatchlist = false;
          // Set message for removal
          this.transactionMessage = `${stock.ticker} removed from watchlist.`;
          this.isWatchlistRemoval = true; // Assuming you're using this flag for styling
          // Manually trigger change detection if needed
          this.cdr.detectChanges();
          // Clear the message after a delay
          setTimeout(() => this.clearTransactionMessage(), 2000);
        },
        error: (error) => {
          console.error('Failed to remove stock from watchlist', error);
          // Optionally, handle the error state in your UI
          this.cdr.detectChanges();
        }
      });
    } else {
      // If it's not in the watchlist, call the API to add it.
      this.stockService.addToWatchlist(stock.ticker, stock.name, stock.lastPrice, stock.change, stock.changePercent).subscribe({
        next: () => {
          stock.isInWatchlist = true;
          // Set message for addition
          this.transactionMessage = `${stock.ticker} added to watchlist.`;
          this.isWatchlistRemoval = false; // Use this flag accordingly or introduce a new flag for add operations
          // Manually trigger change detection if needed
          this.cdr.detectChanges();
          // Clear the message after a delay
          setTimeout(() => this.clearTransactionMessage(), 3000);
        },
        error: (error) => {
          if (error.status === 409) {
            // Assume it's already in the watchlist if there's a conflict
            stock.isInWatchlist = true;
            // You might want to set a message here as well
          } else {
            console.error('Failed to add stock to watchlist', error);
            // Optionally, handle the error state in your UI
          }
          // Manually trigger change detection if needed
          this.cdr.detectChanges();
        }
      });
    }
  }
  

  // Inside StockDetailsComponent class

private fetchInsiderSentimentData(ticker: string): void {
  this.stockService.getInsiderSentiment(ticker).subscribe({
    next: response => {
      this.processInsiderSentimentData(response);
    },
    error: err => {
      console.error('Failed to fetch insider sentiment data:', err);
    }
  });
}

private processInsiderSentimentData(data: any): void {
  const aggregatedData = {
    totalMspr: 0,
    positiveMspr: 0,
    negativeMspr: 0,
    totalChange: 0,
    positiveChange: 0,
    negativeChange: 0,
  };

  data.data.forEach((entry: any) => {
    aggregatedData.totalMspr += entry.mspr;
    aggregatedData.totalChange += entry.change;

    if (entry.mspr > 0) {
      aggregatedData.positiveMspr += entry.mspr;
    } else if (entry.mspr < 0) {
      aggregatedData.negativeMspr += entry.mspr;
    }

    if (entry.change > 0) {
      aggregatedData.positiveChange += entry.change;
    } else if (entry.change < 0) {
      aggregatedData.negativeChange += entry.change;
    }
  });

  this.insiderSentimentData = aggregatedData;
}


  private fetchStockData(symbol: string): void {
    this.isLoading = true; // Start loading
    this.errorMessage = '';
  
    this.stockService.getStockProfile(symbol).pipe(
      switchMap(profile => {
        // Set initial stock details from profile
        this.stockDetails = profile;
        this.stockDetails = {
          ...profile,
          lastTimestamp: profile.lastTimestamp * 1000 // Adjusting lastTimestamp
        };
        let toDate = profile.marketStatus === 'Open' ? new Date().getTime() : profile.lastTimestamp * 1000;
        let toDateFormatted = new Date(toDate).toISOString().split('T')[0];
        let fromDate = new Date(toDate - (24 * 60 * 60 * 1000));
        let fromDateFormatted = new Date(fromDate).toISOString().split('T')[0];
  
        // Parallel requests
        return forkJoin({
          dayData: this.stockService.getDayData(symbol, fromDateFormatted, toDateFormatted),
          summary: this.stockService.getStockSummary(symbol),
          news: this.stockService.getLatestNews(symbol),
          isInWatchlist: this.stockService.isStockInWatchlist(symbol),
          userOwnsStock: this.stockService.checkIfUserOwnsStock(symbol),
          historicalData: this.stockService.getHistoricalData(symbol),
          recommendationTrends: this.stockService.getStockRecommendationTrends(symbol),
          earnings: this.stockService.getCompanyEarnings(symbol),
          insiderSentiment: this.stockService.getInsiderSentiment(symbol)
        });
      })
    ).subscribe({
      next: ({dayData, insiderSentiment, summary, news, isInWatchlist, userOwnsStock, historicalData, recommendationTrends, earnings}) => {
        // Update component state with fetched data
        this.dayData = dayData;
        this.stockSummary = summary;
        this.newsArticles = news;
        this.historicalData = historicalData;
        this.recommendationTrends = recommendationTrends;
        this.companyEarnings = earnings;
        this.processInsiderSentimentData(insiderSentiment); // Process the insider sentiment data
  
        if (this.stockDetails) {
          this.stockDetails.isInWatchlist = isInWatchlist;
          this.stockDetails.userOwnsStock = userOwnsStock.ownsStock;
          this.stockDetails.quantity = userOwnsStock.quantity;
        }
  
        this.isLoading = false; // Data fetching completed
        this.errorMessage = '';
        this.saveState();
      },
      error: err => {
        console.error(err);
        this.errorMessage = 'Failed to retrieve stock details. Please try again.';
        this.isLoading = false; // Ensure loading state is reset on error
      }
    });
  }
}  



