import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { StockService } from '../../stock.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';


interface WatchlistItem {
  symbol: string;
  companyName: string;
  price: number;
  change: number; // 'd' key for change in price
  changePercent: number; // 'dp' key for percentage change
}

@Component({
  selector: 'app-watchlist',
  standalone: true,
  imports: [CommonModule,],
  templateUrl: './watchlist.component.html',
  styleUrl: './watchlist.component.css'
})
export class WatchlistComponent implements OnInit {
  watchlistItems: WatchlistItem[] = [];
  isLoading: boolean = true;
  transactionMessage: string = '';
isWatchlistRemoval: boolean = false;

  constructor(private stockService: StockService, private router: Router,private cdr: ChangeDetectorRef) { }

  ngOnInit() {
    this.loadWatchlist();
  }

  clearTransactionMessage() {
    this.transactionMessage = '';
    this.isWatchlistRemoval = false;
  }
  loadWatchlist() {
    this.isLoading = true; // Start loading
    this.stockService.getWatchlist().subscribe({
      next: (data) => {
        this.watchlistItems = data;
        this.isLoading = false; // Stop loading when data is fetched
      },
      error: (error) => {
        console.error('There was an error!', error);
        this.isLoading = false; // Stop loading on error as well
      }
    });
  }
  
  goToStockDetails(ticker: string) {
    this.router.navigate(['/search', ticker]);
  }

  removeFromWatchlist(symbol: string, event: MouseEvent) {
    event.stopPropagation();
    this.stockService.removeFromWatchlist(symbol).subscribe({
      next: () => {
        // After successfully removing the stock, reload the watchlist
        this.loadWatchlist();
        // Set the transaction message
        this.transactionMessage = `${symbol} removed from watchlist.`;
        this.isWatchlistRemoval = true;
        // Clear transaction message after a delay
        this.cdr.detectChanges(); // Manually trigger change detection

        setTimeout(() => this.clearTransactionMessage(), 3000);
      },
      error: (error) => console.error('Failed to remove stock from watchlist', error)
    });
  }}
