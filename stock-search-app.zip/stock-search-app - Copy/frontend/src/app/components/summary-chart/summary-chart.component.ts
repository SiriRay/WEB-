import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import * as Highcharts from 'highcharts/highstock';
import { HighchartsChartModule } from 'highcharts-angular';

interface StockDetails {
  ticker: string;
  name: string;
  exchange: string;
  lastPrice: number;
  change: number;
  changePercent: number;
  lastTimestamp: number;
  marketStatus: string;
  logo: string;userOwnsStock: boolean;
  quantity: number;  
  isInWatchlist: boolean; // Ensure this is part of your StockDetails interface
}

interface HistoricalData {
  ticker: string,
  queryCount: number,
  resultsCount: number,
  adjusted: true,
  results: HistoricalDataItem[],
  status: string,
  request_id: string,
  count: number
}

interface HistoricalDataItem{
  v: number,
  vw: number,
  o: number,
  c: number,
  h: number,
  l: number,
  t: number,
  n: number
}

interface StockSummary {
  highPrice: number;
  lowPrice: number;
  openPrice: number;
  prevClose: number;
  timestamp: number;
  marketStatus: string;
  ipoStartDate: string;
  industry: string;
  webpage: string;
  companyPeers: string[];
}

@Component({
  selector: 'app-summary-chart',
  standalone: true,
  imports: [CommonModule,RouterModule,HighchartsChartModule],
  templateUrl: './summary-chart.component.html',
  styleUrl: './summary-chart.component.css'
})
export class SummaryChartComponent {
  @Input() stockDetails!: StockDetails;
  @Input() dayData!: HistoricalData;


  constructor(private router: Router) {}


  Highcharts: typeof Highcharts = Highcharts;
  chartConstructor: string = 'stockChart';
  chartOptions!: any;
  priceData: any;


  isLoading: boolean = false;
  isMarketOpen: boolean = true;


  ngOnInit(): void {
    this.priceData = this.dayData.results.map(data => [data.t, data.c]);
    this.renderChart();
  }


  renderChart(): void{
    this.chartOptions = {
      chart: {
        backgroundColor: '#f5f5f5'
      },
      title: {
        text: `${this.dayData.ticker} Hourly Price Variation`,
        style: {
          color: '#767676',
        },
      },
      navigator: {
        enabled: false,
      },
      rangeSelector: {
        enabled: false,
      },
      xAxis: {
        type: 'datetime',
        endOnTick: false,
        startOnTick: false,
        dateTimeLabelFormats: {
          minute: '%H:%M',
        },
      },
      yAxis: {
        opposite: true,
        labels: {
          align: 'left',
          x: -15,
          y: 0,
        },
      },
      plotOptions: {
        spline: {
          color: this.stockDetails.changePercent < 0 ? '#FF0000' : '#00FF00',
          tooltip: {
            valueDecimals: 2,
          },
        },
      },
      series: [
        {
          type: 'spline',
          data: this.priceData,
          name: `${this.dayData.ticker} Stock Price`,
          tooltip: {
            valueDecimals: 2,
          },
          pointPlacement: 'on',
        }
      ]
    };
  }

}
