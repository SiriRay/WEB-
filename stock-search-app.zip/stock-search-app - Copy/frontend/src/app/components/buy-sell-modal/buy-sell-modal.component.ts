import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-buy-sell-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, NgbModule],
  templateUrl: './buy-sell-modal.component.html',
  styleUrl: './buy-sell-modal.component.css'
})

export class BuySellModalComponent implements OnInit  {
  @Input() data!: {
    balance: number;
    stockPrice: number;
    action: string;
    ticker?: string;  
    quantity?: number;
    ownedQuantity?: number;
  };
  @Output() closeModal: EventEmitter<any> = new EventEmitter();

  totalAmount: number = 0;
  errorMessage: string | null = null;

  ngOnInit(): void {
    this.calculateTotal();
  }

  calculateTotal(): void {
    if (this.data.quantity) {
      this.totalAmount = this.data.quantity * this.data.stockPrice;
      this.errorMessage = null; // Reset error message each time calculation is done
    } else {
      this.totalAmount = 0; // Reset total amount if quantity is undefined/null
    }

    if (this.data.action === 'Sell' && !this.canSell()) {
      this.errorMessage = "You cannot sell more stocks than you own.";
    }
  }

  confirmAction(): void {
    if ((this.data.action === 'Buy' && this.canBuy()) || (this.data.action === 'Sell' && this.canSell())) {
      this.closeModal.emit(this.data); // Emitting the data for parent to handle
    } else {
    }
  }
  
  canBuy(): boolean {
    const canBuy = this.data.quantity !== undefined && this.data.quantity > 0 && this.totalAmount <= this.data.balance;
    return canBuy;
  }
  
  canSell(): boolean {
    const canSell = this.data.quantity === 0 || (this.data.quantity! > 0 && this.data.quantity! <= (this.data.ownedQuantity ?? 0));
    return canSell;
  }

  onNoClick(): void {
    // Emit a null or undefined to indicate modal closure without action
    this.closeModal.emit(null);
  }
}
