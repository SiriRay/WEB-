import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, forkJoin, map, switchMap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StockService {
  private apiUrl = '/api'; // Update your API base URL accordingly

  constructor(private http: HttpClient) {}

  searchStocks(query: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/autocomplete?q=${query}`);
  }
  
  getStockProfile(ticker: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/stock-details/${ticker}`);
  }

  getStockSummary(ticker: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/stock-summary/${ticker}`);
  }

  getLatestNews(ticker: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/latest-news/${ticker}`);
  }
  getInsiderSentiment(ticker: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/insider-sentiment/${ticker}`);
  }
  getHistoricalData(symbol: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/historical-data/${symbol}`);
  }

  getDayData(symbol: string, fromDate: string, toDate: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/historical-data/day/${symbol}/${fromDate}/${toDate}`);
  }
  buyStock(stockSymbol: string, quantity: number, pricePerShare: number): Observable<any> {
    const body = { stockSymbol, quantity, pricePerShare };
    return this.http.post(`${this.apiUrl}/buy`, body);
  }

  sellStock(stockSymbol: string, quantity: number, pricePerShare: number): Observable<any> {
    const body = { stockSymbol, quantity, pricePerShare };
    return this.http.post(`${this.apiUrl}/sell`, body);
  }
  getCurrentBalance(): Observable<{ balance: number }> {
    return this.http.get<{ balance: number }>(`${this.apiUrl}/balance`);
  }

  addToWatchlist(symbol: string, companyName: string, price: number, change: number, changePercent:number): Observable<any> {
    const body = { symbol, companyName, price, change, changePercent };
    return this.http.post(`${this.apiUrl}/watchlist/add`, body);
}

  getWatchlist(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/watchlist`);
  }

  removeFromWatchlist(symbol: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/watchlist/remove/${symbol}`);
  }

  isStockInWatchlist(symbol: string): Observable<boolean> {
    return this.http.get<{isInWatchlist: boolean}>(`${this.apiUrl}/watchlist/${symbol}`).pipe(
      map(response => response.isInWatchlist)
    );
  }
  getStockRecommendationTrends(ticker: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/recommendation-trends/${ticker}`);
  }
  getCompanyEarnings(ticker: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/company-earnings/${ticker}`);
  }
  
  checkIfUserOwnsStock(symbol: string): Observable<{ ownsStock: boolean; quantity: number }> {
    return this.http.get<{ ownsStock: boolean; quantity: number }>(`${this.apiUrl}/owns-stock/${symbol}`);
  }
  getTotalCostForStock(symbol: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/total-cost/${symbol}`);
  }
  getPortfolioData(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/portfolio`).pipe(
      switchMap((portfolio: any[]) => {
        // Map each stock in the portfolio to an observable that fetches its details
        const observables: Observable<any>[] = portfolio.map(stock => {
          return this.http.get(`${this.apiUrl}/stock-details/${stock._id}`).pipe(
            map(stockDetails => {
              // Merge the fetched details with the existing stock data
              return { ...stock, details: stockDetails };
            })
          );
        });
        // Combine all observables into a single observable
        return forkJoin(observables);
      })
    );
  }
}  

