import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
// import { provideHttpClient } from '@angular/common/http';
// import { withFetch } from '@angular/fetch';
import { provideHttpClient } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';


export const appConfig: ApplicationConfig = {
  // add http in below providers
  
  // providers: [provideRouter(routes),provideHttpClient(withFetch());]
  providers: [provideRouter(routes), provideHttpClient(), provideAnimationsAsync(), provideAnimationsAsync()]

};