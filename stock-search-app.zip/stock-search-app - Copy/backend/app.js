
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const moment = require('moment'); 
const { MongoClient } = require('mongodb');

const app = express();
const port = process.env.PORT || 3000;

const uri = "mongodb+srv://mirl_007:zkm3vaz8sQcvcWj@cluster1.eccvaer.mongodb.net/?retryWrites=true&w=majority&appName=Cluster1"

const client = new MongoClient(uri);
app.use(cors());
app.use(express.json()); // This ensures that JSON bodies are parsed
app.use(express.static('dist/frontend/browser'))

// Utility functions for Buy/Sell Operations
async function buyStock(stockSymbol, quantity, pricePerShare) {
    const database = client.db("stockTradingApp");
    const wallets = database.collection("wallets");
    const stocks = database.collection("stocks");
    const transactions = database.collection("transactions");

    const totalCost = quantity * pricePerShare;
    const wallet = await wallets.findOne({ _id: "user_id" });

    if (wallet && wallet.balance >= totalCost) {
        await wallets.updateOne({ _id: "user_id" }, { $inc: { balance: -totalCost } });
        await transactions.insertOne({ type: "buy", stockSymbol, quantity, pricePerShare, totalCost, date: new Date().toISOString() });
        await stocks.updateOne({ _id: stockSymbol }, { $inc: { quantity: quantity } }, { upsert: true });
        
        // Retrieve the updated balance after the transaction
        const updatedWallet = await wallets.findOne({ _id: "user_id" });
        const updatedBalance = updatedWallet ? updatedWallet.balance : null;

        return { message: "Stock bought successfully.", updatedBalance };
    } else {
        throw new Error("Not enough balance to complete the transaction.");
    }
}

async function sellStock(stockSymbol, quantity, pricePerShare) {
    const database = client.db("stockTradingApp");
    const wallets = database.collection("wallets");
    const stocks = database.collection("stocks");
    const transactions = database.collection("transactions");

    const stock = await stocks.findOne({ _id: stockSymbol });
    if (!stock || stock.quantity < quantity) {
        throw new Error("Not enough shares to sell.");
    }

    const totalSellValue = quantity * pricePerShare;
    await wallets.updateOne({ _id: "user_id" }, { $inc: { balance: totalSellValue } });
    await transactions.insertOne({ type: "sell", stockSymbol, quantity, pricePerShare, totalSellValue, date: new Date().toISOString() });
    await stocks.updateOne({ _id: stockSymbol }, { $inc: { quantity: -quantity } });

    // Retrieve the updated balance after the transaction
    const updatedWallet = await wallets.findOne({ _id: "user_id" });
    const updatedBalance = updatedWallet ? updatedWallet.balance : null;

    return { message: "Stock sold successfully.", updatedBalance };
}
async function getCurrentBalance() {
    try {
        const database = client.db("stockTradingApp");
        const wallets = database.collection("wallets");
        const wallet = await wallets.findOne({ _id: "user_id" });
        return { balance: wallet ? wallet.balance : null };
    } catch (error) {
        throw new Error("Failed to fetch current balance: " + error);
    }
}

app.get('/api/total-cost/:symbol', async (req, res) => {
    const symbol = req.params.symbol.toUpperCase();
    try {
        const database = client.db("stockTradingApp");
        const transactions = database.collection("transactions");

        const allTransactions = await transactions.find({ stockSymbol: symbol }).sort({date: 1}).toArray();

        let sharesDetails = [];
        let remainingMoney = 0;

        allTransactions.forEach(transaction => {
            if(transaction.type === "buy") {
                // Directly use the numeric values
                sharesDetails.push({quantity: transaction.quantity, pricePerShare: transaction.pricePerShare});
            } else if(transaction.type === "sell") {
                let sellQuantity = transaction.quantity;
                let totalSellValue = sellQuantity * transaction.pricePerShare;
                remainingMoney += totalSellValue;

                for (let i = 0; i < sharesDetails.length && sellQuantity > 0; i++) {
                    if (sellQuantity >= sharesDetails[i].quantity) {
                        sellQuantity -= sharesDetails[i].quantity;
                        sharesDetails[i] = null;
                    } else {
                        sharesDetails[i].quantity -= sellQuantity;
                        sellQuantity = 0;
                    }
                }

                sharesDetails = sharesDetails.filter(detail => detail !== null);
            }
        });

        let totalCost = sharesDetails.reduce((acc, curr) => acc + (curr.quantity * curr.pricePerShare), 0);
        let totalQuantity = sharesDetails.reduce((acc, curr) => acc + curr.quantity, 0);

        // Convert NaN to 0 for a cleaner output if necessary
        totalCost = isNaN(totalCost) ? 0 : totalCost;
        totalQuantity = isNaN(totalQuantity) ? 0 : totalQuantity;
        remainingMoney = isNaN(remainingMoney) ? 0 : remainingMoney;

        res.json({ symbol: symbol, totalCost: totalCost, totalQuantity: totalQuantity, remainingMoney: remainingMoney });
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});





// Buy Endpoint
app.post('/api/buy', async (req, res) => {
    req.body.stockSymbol = req.body.stockSymbol.toUpperCase();
    const { stockSymbol, quantity, pricePerShare } = req.body;
    try {
        const message = await buyStock(stockSymbol, quantity, pricePerShare);
        res.json({ message });
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

// Sell Endpoint
app.post('/api/sell', async (req, res) => {
    req.body.stockSymbol = req.body.stockSymbol.toUpperCase();
    const { stockSymbol, quantity, pricePerShare } = req.body;
    try {
        const message = await sellStock(stockSymbol, quantity, pricePerShare);
        res.json({ message });
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

app.post('/api/watchlist/add', async (req, res) => {
    req.body.symbol = req.body.symbol.toUpperCase();
    const { symbol, companyName, price, change, changePercent } = req.body;
    try {
        const database = client.db("stockTradingApp");
        const watchlist = database.collection("watchlist");

        // Check if the stock already exists in the watchlist
        const exists = await watchlist.findOne({ symbol });
        if (exists) {
            return res.status(409).json({ message: "Stock already in watchlist." });
        }

        await watchlist.insertOne({ symbol, companyName, price, change, changePercent });
        res.status(201).json({ message: "Stock added to watchlist." });
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

app.get('/api/watchlist', async (req, res) => {
    try {
        const database = client.db("stockTradingApp");
        const watchlist = database.collection("watchlist");

        const items = await watchlist.find({}).toArray();
        res.json(items);
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

app.get('/api/watchlist/:symbol', async (req, res) => {
    try {
        const symbol = req.params.symbol.toUpperCase(); // Convert symbol to uppercase
        const database = client.db("stockTradingApp");
        const watchlist = database.collection("watchlist");

        const item = await watchlist.findOne({symbol: symbol});

        if(item) {
            // If the item exists, respond with true
            res.json({ isInWatchlist: true });
        } else {
            // If not found, respond with false
            res.json({ isInWatchlist: false });
        }
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});




app.delete('/api/watchlist/remove/:symbol', async (req, res) => {
    const symbol = req.params.symbol.toUpperCase();
    try {
        const database = client.db("stockTradingApp");
        const watchlist = database.collection("watchlist");

        const result = await watchlist.deleteOne({ symbol });
        if (result.deletedCount === 0) {
            return res.status(404).json({ message: "Stock not found in watchlist." });
        }
        res.json({ message: "Stock removed from watchlist." });
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

app.get('/api/portfolio', async (req, res) => {
    try {
        const database = client.db("stockTradingApp");
        const stocksCollection = database.collection("stocks");
        
        // Fetch all stocks from the collection
        const stocks = await stocksCollection.find({ quantity: { $gt: 0 } }).toArray();
        
        // Return the list of stocks in the response
        res.json(stocks);
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

app.get('/api/owns-stock/:symbol', async (req, res) => {
    const symbol = req.params.symbol.toUpperCase();
    try {
        const database = client.db("stockTradingApp");
        const stocks = database.collection("stocks");
        const stock = await stocks.findOne({ _id: symbol, quantity: { $gt: 0 } });

        if (stock) {
            // If stock is found and quantity is greater than 0, return true and the quantity
            res.json({ ownsStock: true, quantity: stock.quantity });
        } else {
            // If no stock is found, or quantity is 0, return false and quantity 0
            res.json({ ownsStock: false, quantity: 0 });
        }
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});


app.use(cors());
app.use(express.json());

const FINNHUB_API_KEY = 'cnuahk1r01quhjielpvgcnuahk1r01quhjielq00';

// Endpoint for the autocomplete feature
app.get('/api/autocomplete', async (req, res) => {
    const searchTerm = req.query.q;
    if (!searchTerm) {
        return res.status(400).json({ error: 'Query parameter q is required' });
    }
    try {
        const finnhubResponse = await axios.get(`https://finnhub.io/api/v1/search?q=${searchTerm}&token=${FINNHUB_API_KEY}`);
        
        // Filter the results based on the given criteria
        const filteredResults = finnhubResponse.data.result
            .filter(item => item.type === 'Common Stock' && !item.symbol.includes('.'));
        
        // Format the results
        const formattedResults = filteredResults.map(item => ({
            description: item.description,
            displaySymbol: item.displaySymbol,
            symbol: item.symbol,
            type: item.type
        }));

        const response = {
            count: formattedResults.length,
            result: formattedResults
        };
        return res.json(response);
    } catch (error) {
        return res.status(500).json({ error: error.toString() });
    }
});


// Endpoint to get stock details and latest stock quote
app.get('/api/stock-details/:ticker', async (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    
    try {
        const profileResponse = await axios.get(`https://finnhub.io/api/v1/stock/profile2?symbol=${ticker}&token=${FINNHUB_API_KEY}`);
        const quoteResponse = await axios.get(`https://finnhub.io/api/v1/quote?symbol=${ticker}&token=${FINNHUB_API_KEY}`);
        const currentTime = new Date().getTime();
        const lastTradeTime = quoteResponse.data.t * 1000; 
        const marketStatus = currentTime - lastTradeTime < 300000 ? 'Open' : 'Closed'; 
        const combinedData = {
            ticker: profileResponse.data.ticker,
            name: profileResponse.data.name,
            exchange: profileResponse.data.exchange,
            lastPrice: quoteResponse.data.c,
            change: quoteResponse.data.d,
            changePercent: quoteResponse.data.dp,
            lastTimestamp: quoteResponse.data.t,
            marketStatus: marketStatus,
            logo: profileResponse.data.logo 
        };
        res.json(combinedData);
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

const isMarketOpen = (timestamp) => {
    const lastTradeDate = new Date(timestamp * 1000);
    const currentDate = new Date();
    const fiveMinutesAgo = new Date(currentDate.getTime() - (5 * 60 * 1000));
    return lastTradeDate > fiveMinutesAgo;
};

// Endpoint to get the summary of a stock
app.get('/api/stock-summary/:ticker', async (req, res) => {
    const ticker = req.params.ticker.toUpperCase();

    try {
        const [profileRes, quoteRes, peersRes] = await Promise.all([
            axios.get(`https://finnhub.io/api/v1/stock/profile2?symbol=${ticker}&token=${FINNHUB_API_KEY}`),
            axios.get(`https://finnhub.io/api/v1/quote?symbol=${ticker}&token=${FINNHUB_API_KEY}`),
            axios.get(`https://finnhub.io/api/v1/stock/peers?symbol=${ticker}&token=${FINNHUB_API_KEY}`)
        ]);

        const marketStatus = isMarketOpen(quoteRes.data.t) ? 'Open' : 'Close';
        const summaryData = {
            highPrice: quoteRes.data.h,
            lowPrice: quoteRes.data.l,
            openPrice: quoteRes.data.o,
            prevClose: quoteRes.data.pc,
            timestamp: quoteRes.data.t,
            marketStatus: marketStatus, 
            ipoStartDate: profileRes.data.ipo,
            industry: profileRes.data.finnhubIndustry,
            webpage: profileRes.data.weburl,
            companyPeers: peersRes.data 
        };

        res.json(summaryData);
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});


app.get('/api/latest-news/:ticker', async (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    const toDate = new Date();
    const fromDate = new Date();
    fromDate.setDate(toDate.getDate() - 10);

    function getFormattedDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    try {
        const newsResponse = await axios.get(`https://finnhub.io/api/v1/company-news?symbol=${ticker}&from=${getFormattedDate(fromDate)}&to=${getFormattedDate(toDate)}&token=${FINNHUB_API_KEY}`);
        const filteredNews = newsResponse.data.filter(article => 
            article.image && article.headline && article.url && 
            article.datetime && article.summary && article.source
        );
        const latestNews = filteredNews.length > 20 ? filteredNews.slice(0, 20) : filteredNews;
        res.json(latestNews);
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

// Endpoint to get the recommendation trends for a stock
app.get('/api/recommendation-trends/:ticker', async (req, res) => {
    const ticker = req.params.ticker.toUpperCase();

    try {
        const response = await axios.get(`https://finnhub.io/api/v1/stock/recommendation?symbol=${ticker}&token=${FINNHUB_API_KEY}`);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

// Endpoint to get the insider sentiment for a stock
app.get('/api/insider-sentiment/:ticker', async (req, res) => {
    const ticker = req.params.ticker.toUpperCase();
    const defaultFromDate = '2022-01-01';
    
    try {
        const sentimentResponse = await axios.get(`https://finnhub.io/api/v1/stock/insider-sentiment?symbol=${ticker}&from=${defaultFromDate}&token=${FINNHUB_API_KEY}`);
        res.json(sentimentResponse.data);
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

// Endpoint to get the company's earnings
app.get('/api/company-earnings/:ticker', async (req, res) => {
    const ticker = req.params.ticker.toUpperCase();

    try {
        const earningsResponse = await axios.get(`https://finnhub.io/api/v1/stock/earnings?symbol=${ticker}&token=${FINNHUB_API_KEY}`);
        const earningsData = earningsResponse.data.map(item => ({
            actual: item.actual !== null ? item.actual : 0,
            estimate: item.estimate !== null ? item.estimate : 0,
            period: item.period,
            surprise: item.surprise !== null ? item.surprise : 0,
            surprisePercent: item.surprisePercent !== null ? item.surprisePercent : 0,
            symbol: item.symbol
        }));

        res.json(earningsData);
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});


// Route for getting historical data
app.get('/api/historical-data/:symbol', async (req, res) => {
    const symbol = req.params.symbol.toUpperCase();
    try {
        const from = new Date();
        from.setFullYear(from.getFullYear() - 2);
        const to = new Date();
        const fromStr = from.toISOString().split('T')[0];
        const toStr = to.toISOString().split('T')[0];
        const response = await axios.get(`https://api.polygon.io/v2/aggs/ticker/${symbol}/range/1/day/${fromStr}/${toStr}?adjusted=true&sort=asc&apiKey=isBmHEJgemdosTdv8dleBiMg3Nb_UPXd`);
        res.json(response.data);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'An error occurred while fetching historical data' });
    }
});


// Route for getting day data
app.get('/api/historical-data/day/:symbol/:fromDate/:toDate', async (req, res) => {
    const symbol = req.params.symbol.toUpperCase();
    const fromDate = req.params.fromDate;
    const toDate = req.params.toDate;
    try {
        const response = await axios.get(`https://api.polygon.io/v2/aggs/ticker/${symbol}/range/1/hour/${fromDate}/${toDate}?adjusted=true&sort=asc&apiKey=isBmHEJgemdosTdv8dleBiMg3Nb_UPXd`);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: 'An error occurred while fetching historical data' });
    }
});


async function main() {
    try {
        await client.connect();
        console.log("Connected to MongoDB.");

        // Define collections
        const database = client.db("stockTradingApp");
        const wallets = database.collection("wallets");
        const stocks = database.collection("stocks");
        const transactions = database.collection("transactions");
        const watchlist = database.collection("watchlist"); 

        // Initialize wallet balance and stocks for a single user
        await wallets.updateOne({ _id: "user_id" }, { $set: { balance: 25000 } }, { upsert: true });
        console.log("Wallet initialized with $25,000 balance.");
        await stocks.deleteMany({});
        console.log("Stocks collection initialized.");
        await transactions.deleteMany({});
        console.log("Transactions cleared.");
        await watchlist.deleteMany({}); // Clear watchlist collection
        console.log("Watchlist cleared."); 

        // Define API endpoints
        app.get('/api/balance', async (req, res) => {
            try {
                const balance = await getCurrentBalance();
                res.json(balance);
            } catch (error) {
                res.status(500).json({ error: error.toString() });
            }
        });

        // Start the server
        app.listen(port, () => console.log(`Server running on port ${port}`));
    } catch (error) {
        console.error("Could not connect to db", error);
        process.exit(1);
    }
}

// Call main function to start the server
main();